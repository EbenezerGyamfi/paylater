-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 19, 2023 at 11:16 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `paylater`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_menu`
--

DROP TABLE IF EXISTS `admin_menu`;
CREATE TABLE IF NOT EXISTS `admin_menu` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uri` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permission` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_menu`
--

INSERT INTO `admin_menu` (`id`, `parent_id`, `order`, `title`, `icon`, `uri`, `permission`, `created_at`, `updated_at`) VALUES
(1, 0, 2, 'Dashboard', 'fa-bar-chart', '/', NULL, NULL, '2022-12-17 23:27:37'),
(2, 0, 3, 'Admin', 'fa-tasks', '', NULL, NULL, '2022-12-17 23:27:37'),
(3, 2, 4, 'Users', 'fa-users', 'auth/users', NULL, NULL, '2022-12-17 23:27:37'),
(4, 2, 5, 'Roles', 'fa-user', 'auth/roles', NULL, NULL, '2022-12-17 23:27:37'),
(5, 2, 6, 'Permission', 'fa-ban', 'auth/permissions', NULL, NULL, '2022-12-17 23:27:37'),
(6, 2, 7, 'Menu', 'fa-bars', 'auth/menu', NULL, NULL, '2022-12-17 23:27:37'),
(7, 2, 8, 'Operation log', 'fa-history', 'auth/logs', NULL, NULL, '2022-12-17 23:27:37'),
(8, 0, 1, 'Property', 'fa-home', '/properties', '*', '2022-12-17 23:20:36', '2022-12-18 01:18:08'),
(10, 0, 0, 'Customer Request', 'fa-bars', NULL, NULL, '2022-12-18 10:34:00', '2022-12-18 10:34:00'),
(11, 0, 0, 'Customers', 'fa-user', NULL, NULL, '2022-12-18 10:34:23', '2022-12-18 10:34:23');

-- --------------------------------------------------------

--
-- Table structure for table `admin_operation_log`
--

DROP TABLE IF EXISTS `admin_operation_log`;
CREATE TABLE IF NOT EXISTS `admin_operation_log` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `input` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_operation_log_user_id_index` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=537 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_operation_log`
--

INSERT INTO `admin_operation_log` (`id`, `user_id`, `path`, `method`, `ip`, `input`, `created_at`, `updated_at`) VALUES
(1, 1, 'admin', 'GET', '127.0.0.1', '[]', '2022-12-17 23:14:06', '2022-12-17 23:14:06'),
(2, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:16:31', '2022-12-17 23:16:31'),
(3, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Property\",\"icon\":\"fa-bars\",\"uri\":\"\\/properties\",\"roles\":[null],\"permission\":\"*\",\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\"}', '2022-12-17 23:20:36', '2022-12-17 23:20:36'),
(4, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:20:36', '2022-12-17 23:20:36'),
(5, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:20:39', '2022-12-17 23:20:39'),
(6, 1, 'admin/auth/menu/8/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:20:53', '2022-12-17 23:20:53'),
(7, 1, 'admin/auth/menu/8', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Property\",\"icon\":\"fa-bars\",\"uri\":\"properties\",\"roles\":[null],\"permission\":\"*\",\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2022-12-17 23:22:33', '2022-12-17 23:22:33'),
(8, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:22:34', '2022-12-17 23:22:34'),
(9, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:22:43', '2022-12-17 23:22:43'),
(10, 1, 'admin/auth/menu/8/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:22:48', '2022-12-17 23:22:48'),
(11, 1, 'admin/auth/menu/8', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Property\",\"icon\":\"fa-bars\",\"uri\":\"\\/property-types\",\"roles\":[null],\"permission\":\"*\",\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2022-12-17 23:23:15', '2022-12-17 23:23:15'),
(12, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:23:15', '2022-12-17 23:23:15'),
(13, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:23:19', '2022-12-17 23:23:19'),
(14, 1, 'admin', 'GET', '127.0.0.1', '[]', '2022-12-17 23:23:36', '2022-12-17 23:23:36'),
(15, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:23:44', '2022-12-17 23:23:44'),
(16, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:23:52', '2022-12-17 23:23:52'),
(17, 1, 'admin/auth/menu/8/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:23:55', '2022-12-17 23:23:55'),
(18, 1, 'admin/auth/menu/8/edit', 'GET', '127.0.0.1', '[]', '2022-12-17 23:27:18', '2022-12-17 23:27:18'),
(19, 1, 'admin/auth/menu/8', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Property\",\"icon\":\"fa-bars\",\"uri\":\"\\/property-types\",\"roles\":[null],\"permission\":\"*\",\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\",\"_method\":\"PUT\"}', '2022-12-17 23:27:31', '2022-12-17 23:27:31'),
(20, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:27:31', '2022-12-17 23:27:31'),
(21, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\",\"_order\":\"[{\\\"id\\\":8},{\\\"id\\\":1},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]}]\"}', '2022-12-17 23:27:37', '2022-12-17 23:27:37'),
(22, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:27:37', '2022-12-17 23:27:37'),
(23, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:27:44', '2022-12-17 23:27:44'),
(24, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:27:55', '2022-12-17 23:27:55'),
(25, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\",\"_order\":\"[{\\\"id\\\":8},{\\\"id\\\":1},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]}]\"}', '2022-12-17 23:27:59', '2022-12-17 23:27:59'),
(26, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:28:00', '2022-12-17 23:28:00'),
(27, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:32:48', '2022-12-17 23:32:48'),
(28, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\",\"_order\":\"[{\\\"id\\\":8},{\\\"id\\\":1},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]}]\"}', '2022-12-17 23:32:50', '2022-12-17 23:32:50'),
(29, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:32:50', '2022-12-17 23:32:50'),
(30, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:32:52', '2022-12-17 23:32:52'),
(31, 1, 'admin/auth/menu/8/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:33:21', '2022-12-17 23:33:21'),
(32, 1, 'admin/auth/menu/8', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Property\",\"icon\":\"fa-bars\",\"uri\":\"property-types\",\"roles\":[null],\"permission\":\"*\",\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2022-12-17 23:33:41', '2022-12-17 23:33:41'),
(33, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:33:42', '2022-12-17 23:33:42'),
(34, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\",\"_order\":\"[{\\\"id\\\":8},{\\\"id\\\":1},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]}]\"}', '2022-12-17 23:33:44', '2022-12-17 23:33:44'),
(35, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:33:44', '2022-12-17 23:33:44'),
(36, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:33:46', '2022-12-17 23:33:46'),
(37, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:35:46', '2022-12-17 23:35:46'),
(38, 1, 'admin', 'GET', '127.0.0.1', '[]', '2022-12-17 23:36:09', '2022-12-17 23:36:09'),
(39, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:36:27', '2022-12-17 23:36:27'),
(40, 1, 'admin/auth/menu/8/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:36:31', '2022-12-17 23:36:31'),
(41, 1, 'admin/auth/menu/8', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Property\",\"icon\":\"fa-bars\",\"uri\":\"\\/properties\",\"roles\":[null],\"permission\":\"*\",\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2022-12-17 23:36:45', '2022-12-17 23:36:45'),
(42, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:36:45', '2022-12-17 23:36:45'),
(43, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\",\"_order\":\"[{\\\"id\\\":8},{\\\"id\\\":1},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]}]\"}', '2022-12-17 23:36:47', '2022-12-17 23:36:47'),
(44, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:36:48', '2022-12-17 23:36:48'),
(45, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:36:50', '2022-12-17 23:36:50'),
(46, 1, 'admin/auth/menu/8/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:36:53', '2022-12-17 23:36:53'),
(47, 1, 'admin/auth/menu/8', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Property\",\"icon\":\"fa-bars\",\"uri\":\"\\/properties\",\"roles\":[null],\"permission\":\"*\",\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\",\"_method\":\"PUT\"}', '2022-12-17 23:37:24', '2022-12-17 23:37:24'),
(48, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:37:25', '2022-12-17 23:37:25'),
(49, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:37:27', '2022-12-17 23:37:27'),
(50, 1, 'admin/auth/menu/8/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:37:29', '2022-12-17 23:37:29'),
(51, 1, 'admin/auth/menu/8', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Property\",\"icon\":\"fa-bars\",\"uri\":\"\\/properties\",\"roles\":[null],\"permission\":\"*\",\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2022-12-17 23:37:32', '2022-12-17 23:37:32'),
(52, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:37:33', '2022-12-17 23:37:33'),
(53, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:37:40', '2022-12-17 23:37:40'),
(54, 1, 'admin/auth/menu/8/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-17 23:37:50', '2022-12-17 23:37:50'),
(55, 1, 'admin/auth/menu/8', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Property\",\"icon\":\"fa-bars\",\"uri\":\"\\/properties\",\"roles\":[null],\"permission\":\"*\",\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2022-12-17 23:37:55', '2022-12-17 23:37:55'),
(56, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-17 23:37:56', '2022-12-17 23:37:56'),
(57, 1, 'admin', 'GET', '127.0.0.1', '[]', '2022-12-18 00:39:43', '2022-12-18 00:39:43'),
(58, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 00:39:48', '2022-12-18 00:39:48'),
(59, 1, 'admin/auth/menu/8/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 00:39:50', '2022-12-18 00:39:50'),
(60, 1, 'admin/property-types', 'GET', '127.0.0.1', '[]', '2022-12-18 00:46:31', '2022-12-18 00:46:31'),
(61, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 00:46:40', '2022-12-18 00:46:40'),
(62, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 00:57:32', '2022-12-18 00:57:32'),
(63, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 00:57:47', '2022-12-18 00:57:47'),
(64, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 01:02:48', '2022-12-18 01:02:48'),
(65, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:02:54', '2022-12-18 01:02:54'),
(66, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 01:04:01', '2022-12-18 01:04:01'),
(67, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:04:07', '2022-12-18 01:04:07'),
(68, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 01:06:43', '2022-12-18 01:06:43'),
(69, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:06:51', '2022-12-18 01:06:51'),
(70, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:06:55', '2022-12-18 01:06:55'),
(71, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 01:09:46', '2022-12-18 01:09:46'),
(72, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 01:10:38', '2022-12-18 01:10:38'),
(73, 1, 'admin', 'GET', '127.0.0.1', '[]', '2022-12-18 01:13:27', '2022-12-18 01:13:27'),
(74, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:13:30', '2022-12-18 01:13:30'),
(75, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:13:35', '2022-12-18 01:13:35'),
(76, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 01:14:23', '2022-12-18 01:14:23'),
(77, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 01:14:56', '2022-12-18 01:14:56'),
(78, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 01:16:27', '2022-12-18 01:16:27'),
(79, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:17:12', '2022-12-18 01:17:12'),
(80, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Property Type\",\"icon\":\"fa-bars\",\"uri\":\"\\/property-types\",\"roles\":[null],\"permission\":null,\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\"}', '2022-12-18 01:17:34', '2022-12-18 01:17:34'),
(81, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-18 01:17:35', '2022-12-18 01:17:35'),
(82, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-18 01:17:39', '2022-12-18 01:17:39'),
(83, 1, 'admin/auth/menu/8/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:17:46', '2022-12-18 01:17:46'),
(84, 1, 'admin/auth/menu/8', 'PUT', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Property\",\"icon\":\"fa-home\",\"uri\":\"\\/properties\",\"roles\":[null],\"permission\":\"*\",\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/auth\\/menu\"}', '2022-12-18 01:18:08', '2022-12-18 01:18:08'),
(85, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-18 01:18:08', '2022-12-18 01:18:08'),
(86, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-18 01:18:12', '2022-12-18 01:18:12'),
(87, 1, 'admin/property-types', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:18:19', '2022-12-18 01:18:19'),
(88, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 01:19:12', '2022-12-18 01:19:12'),
(89, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:19:15', '2022-12-18 01:19:15'),
(90, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 01:23:59', '2022-12-18 01:23:59'),
(91, 1, 'admin/property-types', 'GET', '127.0.0.1', '[]', '2022-12-18 01:24:05', '2022-12-18 01:24:05'),
(92, 1, 'admin/property-types/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:24:08', '2022-12-18 01:24:08'),
(93, 1, 'admin/property-types/create', 'GET', '127.0.0.1', '[]', '2022-12-18 01:24:48', '2022-12-18 01:24:48'),
(94, 1, 'admin/property-types', 'POST', '127.0.0.1', '{\"name\":\"property one\",\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/property-types\"}', '2022-12-18 01:24:57', '2022-12-18 01:24:57'),
(95, 1, 'admin/property-types', 'GET', '127.0.0.1', '[]', '2022-12-18 01:24:57', '2022-12-18 01:24:57'),
(96, 1, 'admin/property-types/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:25:00', '2022-12-18 01:25:00'),
(97, 1, 'admin/property-types', 'POST', '127.0.0.1', '{\"name\":\"Apartment\",\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/property-types\"}', '2022-12-18 01:25:10', '2022-12-18 01:25:10'),
(98, 1, 'admin/property-types', 'GET', '127.0.0.1', '[]', '2022-12-18 01:25:10', '2022-12-18 01:25:10'),
(99, 1, 'admin/property-types/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:25:12', '2022-12-18 01:25:12'),
(100, 1, 'admin/property-types', 'POST', '127.0.0.1', '{\"name\":\"Hostels\",\"_token\":\"vbHPlexYN1SsBo5Kjej98ffhp4FmgLayHIU1kCXR\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/property-types\"}', '2022-12-18 01:25:18', '2022-12-18 01:25:18'),
(101, 1, 'admin/property-types', 'GET', '127.0.0.1', '[]', '2022-12-18 01:25:18', '2022-12-18 01:25:18'),
(102, 1, 'admin/property-types/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:25:19', '2022-12-18 01:25:19'),
(103, 1, 'admin/property-types', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:25:28', '2022-12-18 01:25:28'),
(104, 1, 'admin/property-types/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:25:33', '2022-12-18 01:25:33'),
(105, 1, 'admin/property-types', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:25:35', '2022-12-18 01:25:35'),
(106, 1, 'admin/property-types', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:25:42', '2022-12-18 01:25:42'),
(107, 1, 'admin/property-types', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:27:22', '2022-12-18 01:27:22'),
(108, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:27:25', '2022-12-18 01:27:25'),
(109, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:27:30', '2022-12-18 01:27:30'),
(110, 1, 'admin/property-types', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 01:27:35', '2022-12-18 01:27:35'),
(111, 1, 'admin', 'GET', '127.0.0.1', '[]', '2022-12-18 08:19:58', '2022-12-18 08:19:58'),
(112, 1, 'admin', 'GET', '127.0.0.1', '[]', '2022-12-18 08:20:03', '2022-12-18 08:20:03'),
(113, 1, 'admin/property-types', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 08:20:09', '2022-12-18 08:20:09'),
(114, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 08:20:19', '2022-12-18 08:20:19'),
(115, 1, 'admin/property-types', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 08:21:08', '2022-12-18 08:21:08'),
(116, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 08:21:11', '2022-12-18 08:21:11'),
(117, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 08:43:45', '2022-12-18 08:43:45'),
(118, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 08:43:47', '2022-12-18 08:43:47'),
(119, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 08:43:48', '2022-12-18 08:43:48'),
(120, 1, 'admin', 'GET', '127.0.0.1', '[]', '2022-12-18 08:45:01', '2022-12-18 08:45:01'),
(121, 1, 'admin/property-types', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 08:45:04', '2022-12-18 08:45:04'),
(122, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 08:45:05', '2022-12-18 08:45:05'),
(123, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 08:45:07', '2022-12-18 08:45:07'),
(124, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 08:46:12', '2022-12-18 08:46:12'),
(125, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 08:47:49', '2022-12-18 08:47:49'),
(126, 1, 'admin/property-types', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 08:59:43', '2022-12-18 08:59:43'),
(127, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 08:59:44', '2022-12-18 08:59:44'),
(128, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 08:59:45', '2022-12-18 08:59:45'),
(129, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 08:59:46', '2022-12-18 08:59:46'),
(130, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 08:59:47', '2022-12-18 08:59:47'),
(131, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 09:01:21', '2022-12-18 09:01:21'),
(132, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"property_type\":\"2\",\"_file_sort_\":{\"images\":null},\"images\":null,\"description\":null,\"price\":null,\"_token\":\"N9sCWOfmWWYCyGIvwfMPk2v9msNl7aDh7vcjEyE8\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-18 09:01:33', '2022-12-18 09:01:33'),
(133, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 09:01:34', '2022-12-18 09:01:34'),
(134, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 09:01:47', '2022-12-18 09:01:47'),
(135, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"property_type\":\"2\",\"_token\":\"N9sCWOfmWWYCyGIvwfMPk2v9msNl7aDh7vcjEyE8\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-18 09:01:52', '2022-12-18 09:01:52'),
(136, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"property_type\":\"1\",\"_token\":\"N9sCWOfmWWYCyGIvwfMPk2v9msNl7aDh7vcjEyE8\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-18 09:02:08', '2022-12-18 09:02:08'),
(137, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 09:02:08', '2022-12-18 09:02:08'),
(138, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 09:04:23', '2022-12-18 09:04:23'),
(139, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 09:21:01', '2022-12-18 09:21:01'),
(140, 1, 'admin/property-types', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 09:21:09', '2022-12-18 09:21:09'),
(141, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 09:21:11', '2022-12-18 09:21:11'),
(142, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 09:22:10', '2022-12-18 09:22:10'),
(143, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 09:22:24', '2022-12-18 09:22:24'),
(144, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 09:23:09', '2022-12-18 09:23:09'),
(145, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 09:23:29', '2022-12-18 09:23:29'),
(146, 1, 'admin/auth/menu/9', 'DELETE', '127.0.0.1', '{\"_method\":\"delete\",\"_token\":\"N9sCWOfmWWYCyGIvwfMPk2v9msNl7aDh7vcjEyE8\"}', '2022-12-18 09:23:33', '2022-12-18 09:23:33'),
(147, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 09:23:34', '2022-12-18 09:23:34'),
(148, 1, 'admin/property-types', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 09:23:39', '2022-12-18 09:23:39'),
(149, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 09:24:31', '2022-12-18 09:24:31'),
(150, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 09:24:34', '2022-12-18 09:24:34'),
(151, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 09:24:37', '2022-12-18 09:24:37'),
(152, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 09:26:20', '2022-12-18 09:26:20'),
(153, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"_file_sort_\":{\"images\":null},\"title\":\"asdjsad\",\"description\":\"<p>sadkjhdsjhdsajhsad<\\/p>\",\"price\":\"3\",\"amenities\":\"asddadsda\",\"property_type\":\"sadsa\",\"token\":\"asddsa\",\"location\":\"asdsdadsa\",\"status\":\"saddsa\",\"area\":\"saddsadsa\",\"bed\":\"5\",\"bath\":\"2\",\"garage\":\"2\",\"url\":\"asddsadsdsasd\",\"_token\":\"N9sCWOfmWWYCyGIvwfMPk2v9msNl7aDh7vcjEyE8\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-18 09:27:21', '2022-12-18 09:27:21'),
(154, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 09:27:22', '2022-12-18 09:27:22'),
(155, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"_file_sort_\":{\"images\":null},\"title\":\"asdjsad\",\"description\":\"<p>sadkjhdsjhdsajhsad<\\/p>\",\"price\":\"3\",\"amenities\":\"asddadsda\",\"property_type\":\"sadsa\",\"token\":\"asddsa\",\"location\":\"asdsdadsa\",\"status\":\"saddsa\",\"area\":\"saddsadsa\",\"bed\":\"5\",\"bath\":\"2\",\"garage\":\"2\",\"url\":\"asddsadsdsasd\",\"_token\":\"N9sCWOfmWWYCyGIvwfMPk2v9msNl7aDh7vcjEyE8\"}', '2022-12-18 09:30:07', '2022-12-18 09:30:07'),
(156, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 09:30:07', '2022-12-18 09:30:07'),
(157, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 09:36:58', '2022-12-18 09:36:58'),
(158, 1, 'admin/properties/2/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 09:37:12', '2022-12-18 09:37:12'),
(159, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 09:38:57', '2022-12-18 09:38:57'),
(160, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 10:26:05', '2022-12-18 10:26:05'),
(161, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 10:27:43', '2022-12-18 10:27:43'),
(162, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 10:28:17', '2022-12-18 10:28:17'),
(163, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 10:28:42', '2022-12-18 10:28:42'),
(164, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 10:28:57', '2022-12-18 10:28:57'),
(165, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 10:29:22', '2022-12-18 10:29:22'),
(166, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 10:29:49', '2022-12-18 10:29:49'),
(167, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 10:30:39', '2022-12-18 10:30:39'),
(168, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 10:31:41', '2022-12-18 10:31:41'),
(169, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 10:31:52', '2022-12-18 10:31:52'),
(170, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 10:32:08', '2022-12-18 10:32:08'),
(171, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-18 10:32:15', '2022-12-18 10:32:15'),
(172, 1, 'admin/auth/setting', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 10:32:33', '2022-12-18 10:32:33'),
(173, 1, 'admin/auth/setting', 'PUT', '127.0.0.1', '{\"name\":\"Administrator\",\"password\":\"$2y$10$FPPW4yDXBBMP8s3ybydB0.4X5EfK94Q1accNNkchUkQI.3ch4d.86\",\"password_confirmation\":\"$2y$10$FPPW4yDXBBMP8s3ybydB0.4X5EfK94Q1accNNkchUkQI.3ch4d.86\",\"_token\":\"N9sCWOfmWWYCyGIvwfMPk2v9msNl7aDh7vcjEyE8\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-18 10:32:43', '2022-12-18 10:32:43'),
(174, 1, 'admin/auth/setting', 'GET', '127.0.0.1', '[]', '2022-12-18 10:32:43', '2022-12-18 10:32:43'),
(175, 1, 'admin/auth/setting', 'GET', '127.0.0.1', '[]', '2022-12-18 10:33:00', '2022-12-18 10:33:00'),
(176, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 10:33:23', '2022-12-18 10:33:23'),
(177, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 10:33:48', '2022-12-18 10:33:48'),
(178, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Customer Request\",\"icon\":\"fa-bars\",\"uri\":null,\"roles\":[null],\"permission\":null,\"_token\":\"N9sCWOfmWWYCyGIvwfMPk2v9msNl7aDh7vcjEyE8\"}', '2022-12-18 10:34:00', '2022-12-18 10:34:00'),
(179, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-18 10:34:00', '2022-12-18 10:34:00'),
(180, 1, 'admin/auth/menu', 'POST', '127.0.0.1', '{\"parent_id\":\"0\",\"title\":\"Customers\",\"icon\":\"fa-user\",\"uri\":null,\"roles\":[null],\"permission\":null,\"_token\":\"N9sCWOfmWWYCyGIvwfMPk2v9msNl7aDh7vcjEyE8\"}', '2022-12-18 10:34:23', '2022-12-18 10:34:23'),
(181, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-18 10:34:23', '2022-12-18 10:34:23'),
(182, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-18 10:34:26', '2022-12-18 10:34:26'),
(183, 1, 'admin/auth/menu', 'GET', '127.0.0.1', '[]', '2022-12-18 10:35:13', '2022-12-18 10:35:13'),
(184, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 10:35:24', '2022-12-18 10:35:24'),
(185, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 10:35:26', '2022-12-18 10:35:26'),
(186, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 10:35:30', '2022-12-18 10:35:30'),
(187, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 10:35:35', '2022-12-18 10:35:35'),
(188, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"_file_sort_\":{\"images\":null},\"title\":\"asdsad\",\"description\":\"<p>asddsa<\\/p>\",\"price\":\"4\",\"amenities\":\"saddsads\",\"property_type\":\"sads\",\"token\":\"sadsda\",\"location\":\"sadds\",\"status\":\"asddsa\",\"area\":\"sddsd\",\"bed\":\"4\",\"bath\":\"3\",\"garage\":\"2\",\"url\":\"sadadsd\",\"_token\":\"N9sCWOfmWWYCyGIvwfMPk2v9msNl7aDh7vcjEyE8\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-18 10:38:46', '2022-12-18 10:38:46'),
(189, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-18 10:38:46', '2022-12-18 10:38:46'),
(190, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 10:51:31', '2022-12-18 10:51:31'),
(191, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 10:52:34', '2022-12-18 10:52:34'),
(192, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 10:53:15', '2022-12-18 10:53:15'),
(193, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 10:53:20', '2022-12-18 10:53:20'),
(194, 1, 'admin', 'GET', '127.0.0.1', '[]', '2022-12-18 10:55:51', '2022-12-18 10:55:51'),
(195, 1, 'admin', 'GET', '127.0.0.1', '[]', '2022-12-18 10:55:58', '2022-12-18 10:55:58'),
(196, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 17:49:40', '2022-12-18 17:49:40'),
(197, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 17:49:43', '2022-12-18 17:49:43'),
(198, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 17:49:44', '2022-12-18 17:49:44'),
(199, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-18 18:24:17', '2022-12-18 18:24:17'),
(200, 1, 'admin', 'GET', '127.0.0.1', '[]', '2022-12-23 21:39:26', '2022-12-23 21:39:26'),
(201, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-23 21:39:30', '2022-12-23 21:39:30'),
(202, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-23 21:39:34', '2022-12-23 21:39:34'),
(203, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-23 21:39:37', '2022-12-23 21:39:37'),
(204, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-23 21:57:17', '2022-12-23 21:57:17'),
(205, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-23 22:07:43', '2022-12-23 22:07:43'),
(206, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"_file_sort_\":{\"images\":null},\"title\":\"asddadsda\",\"description\":\"<p>asddadsda<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"3\",\"amenities\":\"asddadsda\",\"property_type\":\"sadsa\",\"token\":\"sadsda\",\"location\":\"asdsdadsa\",\"status\":\"saddsa\",\"area\":\"saddsadsa\",\"bed\":\"2\",\"bath\":\"1\",\"garage\":\"3\",\"url\":\"asddsadsdsasd\",\"_token\":\"pTl1mguqyjdHoijMX2P9KNIIMxM6jT54OuVv5GZL\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-23 22:27:02', '2022-12-23 22:27:02'),
(207, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-23 22:27:04', '2022-12-23 22:27:04'),
(208, 1, 'admin', 'GET', '127.0.0.1', '[]', '2022-12-24 08:40:42', '2022-12-24 08:40:42'),
(209, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 08:40:47', '2022-12-24 08:40:47'),
(210, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 08:41:26', '2022-12-24 08:41:26'),
(211, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 08:48:14', '2022-12-24 08:48:14'),
(212, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 08:48:18', '2022-12-24 08:48:18'),
(213, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"_file_sort_\":{\"images\":null},\"title\":\"adssfdf\",\"description\":\"<p>sdfdsf<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"2\",\"amenities\":\"dsfdsffd\",\"property_type\":\"sdfdsf\",\"token\":\"sdfds\",\"location\":\"dsffdsfd\",\"status\":\"dsaffd\",\"area\":\"dsffd\",\"bed\":\"3\",\"bath\":\"3\",\"garage\":\"3\",\"url\":\"asddsadsdsasd\",\"_token\":\"KMlQhMrYXRmAUXuGzyCRIZttiHDgd8wlVnUOa5va\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 08:49:15', '2022-12-24 08:49:15'),
(214, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 08:49:16', '2022-12-24 08:49:16'),
(215, 1, 'admin', 'GET', '127.0.0.1', '[]', '2022-12-24 09:13:56', '2022-12-24 09:13:56'),
(216, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 09:13:59', '2022-12-24 09:13:59'),
(217, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 09:14:08', '2022-12-24 09:14:08'),
(218, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"_file_sort_\":{\"images\":null},\"title\":\"XFSDF\",\"description\":\"<p>ZXCCXZ<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"3\",\"amenities\":\"ZXCCXZCX\",\"property_type\":\"ZXCXCXC\",\"token\":\"XZCCXC\",\"location\":\"XZCC\",\"status\":\"XC\",\"area\":\"ZXCCZC\",\"bed\":\"2\",\"bath\":\"2\",\"garage\":\"2\",\"url\":\"ZXCCC\",\"_token\":\"ycxe2sPHx0o0rcPBW3nNTavO5dw578SXBc2vIlji\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 09:14:38', '2022-12-24 09:14:38'),
(219, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 09:14:38', '2022-12-24 09:14:38'),
(220, 1, 'admin', 'GET', '127.0.0.1', '[]', '2022-12-24 09:28:16', '2022-12-24 09:28:16'),
(221, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 09:28:19', '2022-12-24 09:28:19'),
(222, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 09:28:23', '2022-12-24 09:28:23'),
(223, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 09:28:29', '2022-12-24 09:28:29'),
(224, 1, 'admin/properties/5/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 09:28:33', '2022-12-24 09:28:33'),
(225, 1, 'admin', 'GET', '127.0.0.1', '[]', '2022-12-24 09:30:41', '2022-12-24 09:30:41'),
(226, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 09:30:44', '2022-12-24 09:30:44'),
(227, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 09:30:47', '2022-12-24 09:30:47'),
(228, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"_file_sort_\":{\"images\":null},\"title\":\"sasadsad\",\"description\":\"<p>sadad<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"3\",\"amenities\":\"sadsdad\",\"property_type\":\"asdda\",\"token\":\"sadsad\",\"location\":\"sdd\",\"status\":\"sadsda\",\"area\":\"saddds\",\"bed\":\"4\",\"bath\":\"3\",\"garage\":\"2\",\"url\":\"asddsads\",\"_token\":\"ngd8AlomZTjiUbarUUxsH55QR3J24zMeyDrWLKz9\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 09:31:10', '2022-12-24 09:31:10'),
(229, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 09:31:11', '2022-12-24 09:31:11'),
(230, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 09:32:21', '2022-12-24 09:32:21'),
(231, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"_file_sort_\":{\"images\":null},\"title\":\"zxccxz\",\"description\":\"<p>zxcz<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"4\",\"amenities\":\"ZXCCXZCX\",\"property_type\":\"sadsa\",\"token\":\"asddsa\",\"location\":\"asdsdadsa\",\"status\":\"asddsa\",\"area\":\"ZXCCZC\",\"bed\":\"4\",\"bath\":\"1\",\"garage\":\"3\",\"url\":\"ZXCCC\",\"_token\":\"ngd8AlomZTjiUbarUUxsH55QR3J24zMeyDrWLKz9\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 09:32:48', '2022-12-24 09:32:48'),
(232, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 09:32:49', '2022-12-24 09:32:49'),
(233, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 09:34:46', '2022-12-24 09:34:46'),
(234, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"_file_sort_\":{\"images\":null},\"title\":\"dfgs\",\"description\":\"<p>sdfdsfd<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"3\",\"amenities\":\"sdf\",\"property_type\":\"sads\",\"token\":\"sdfds\",\"location\":\"sdd\",\"status\":\"dsaffd\",\"area\":\"dsffd\",\"bed\":\"3\",\"bath\":\"3\",\"garage\":\"2\",\"url\":\"asddsads\",\"_token\":\"ngd8AlomZTjiUbarUUxsH55QR3J24zMeyDrWLKz9\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 09:35:20', '2022-12-24 09:35:20'),
(235, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-24 09:35:21', '2022-12-24 09:35:21'),
(236, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"_file_sort_\":{\"images\":null},\"title\":\"dfgs\",\"description\":\"<p>sdfdsfd<\\/p>\\r\\n\\r\\n<p>&nbsp;<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"3\",\"amenities\":\"sdf\",\"property_type\":\"sads\",\"token\":\"sdfds\",\"location\":\"sdd\",\"status\":\"dsaffd\",\"area\":\"dsffd\",\"bed\":\"3\",\"bath\":\"3\",\"garage\":\"2\",\"url\":\"asddsads\",\"_token\":\"ngd8AlomZTjiUbarUUxsH55QR3J24zMeyDrWLKz9\"}', '2022-12-24 09:39:08', '2022-12-24 09:39:08'),
(237, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-24 09:39:08', '2022-12-24 09:39:08'),
(238, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-24 09:45:44', '2022-12-24 09:45:44'),
(239, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"_file_sort_\":{\"images\":null},\"title\":\"aa\",\"description\":\"<p>dad<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"3\",\"amenities\":\"asddadsda\",\"property_type\":\"sadsa\",\"token\":\"asddsa\",\"location\":\"sdd\",\"status\":\"dsaffd\",\"area\":\"saddds\",\"bed\":\"2\",\"bath\":\"2\",\"garage\":\"3\",\"url\":\"sadadsd\",\"_token\":\"ngd8AlomZTjiUbarUUxsH55QR3J24zMeyDrWLKz9\"}', '2022-12-24 09:46:15', '2022-12-24 09:46:15'),
(240, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-24 09:46:15', '2022-12-24 09:46:15'),
(241, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-24 09:48:12', '2022-12-24 09:48:12'),
(242, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 09:48:55', '2022-12-24 09:48:55'),
(243, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 09:49:05', '2022-12-24 09:49:05'),
(244, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 09:49:08', '2022-12-24 09:49:08'),
(245, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-24 09:52:16', '2022-12-24 09:52:16'),
(246, 1, 'admin', 'GET', '127.0.0.1', '[]', '2022-12-24 10:04:24', '2022-12-24 10:04:24'),
(247, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 10:04:31', '2022-12-24 10:04:31'),
(248, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 10:04:40', '2022-12-24 10:04:40'),
(249, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"dsacd\",\"description\":\"<p>xcx<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"1\",\"amenities\":\"saddsads\",\"property_type\":\"sadsa\",\"token\":\"sadsda\",\"location\":\"sdd\",\"status\":\"dd\",\"area\":\"sdds\",\"bed\":\"2\",\"bath\":\"2\",\"garage\":\"2\",\"url\":\"asddsads\",\"_token\":\"ngd8AlomZTjiUbarUUxsH55QR3J24zMeyDrWLKz9\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 10:05:24', '2022-12-24 10:05:24'),
(250, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-24 10:05:25', '2022-12-24 10:05:25'),
(251, 1, 'admin', 'GET', '127.0.0.1', '[]', '2022-12-24 13:34:08', '2022-12-24 13:34:08'),
(252, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 13:34:11', '2022-12-24 13:34:11'),
(253, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 13:34:13', '2022-12-24 13:34:13'),
(254, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 13:34:15', '2022-12-24 13:34:15'),
(255, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 13:34:19', '2022-12-24 13:34:19'),
(256, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"sasdsd\",\"description\":\"<p>asdsada<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"4\",\"amenities\":\"saddsda\",\"property_type\":\"asddad\",\"token\":\"sadddsa\",\"location\":\"asdadda\",\"status\":\"asdsad\",\"area\":\"asdda\",\"bed\":\"1\",\"bath\":\"2\",\"garage\":\"2\",\"url\":\"asdsadds\",\"_token\":\"cIReRaVjnFxaaOrWq0cJKljBwL6Si5Klk8LjzPpZ\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 13:34:44', '2022-12-24 13:34:44'),
(257, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-24 13:34:45', '2022-12-24 13:34:45'),
(258, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"sasdsd\",\"description\":\"<p>asdsada<\\/p>\\r\\n\\r\\n<p>&nbsp;<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"4\",\"amenities\":\"saddsda\",\"property_type\":\"asddad\",\"token\":\"sadddsa\",\"location\":\"asdadda\",\"status\":\"asdsad\",\"area\":\"asdda\",\"bed\":\"1\",\"bath\":\"2\",\"garage\":\"2\",\"url\":\"asdsadds\",\"_token\":\"cIReRaVjnFxaaOrWq0cJKljBwL6Si5Klk8LjzPpZ\"}', '2022-12-24 13:36:25', '2022-12-24 13:36:25'),
(259, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-24 13:36:25', '2022-12-24 13:36:25'),
(260, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-24 13:36:44', '2022-12-24 13:36:44'),
(261, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"scas\",\"description\":\"<p>zxccxz<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"2\",\"amenities\":\"zxccxz\",\"property_type\":\"zxczc\",\"token\":\"zxccx\",\"location\":\"xzccxz\",\"status\":\"xzcc\",\"area\":\"zcxzxc\",\"bed\":\"3\",\"bath\":\"3\",\"garage\":\"2\",\"url\":\"zxczccx\",\"_token\":\"cIReRaVjnFxaaOrWq0cJKljBwL6Si5Klk8LjzPpZ\"}', '2022-12-24 13:37:05', '2022-12-24 13:37:05'),
(262, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 13:37:05', '2022-12-24 13:37:05'),
(263, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 13:38:30', '2022-12-24 13:38:30'),
(264, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 13:38:40', '2022-12-24 13:38:40'),
(265, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"ssadda\",\"description\":\"<p>assad<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"2\",\"amenities\":\"sasda\",\"property_type\":\"saddsa\",\"token\":\"asdsad\",\"location\":\"saddsa\",\"status\":\"saddsa\",\"area\":\"saddsa\",\"bed\":\"2\",\"bath\":\"1\",\"garage\":\"1\",\"url\":\"saddsad\",\"_token\":\"cIReRaVjnFxaaOrWq0cJKljBwL6Si5Klk8LjzPpZ\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 13:39:07', '2022-12-24 13:39:07'),
(266, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 13:39:08', '2022-12-24 13:39:08'),
(267, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 13:45:47', '2022-12-24 13:45:47'),
(268, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 13:45:49', '2022-12-24 13:45:49'),
(269, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"asddsadsa\",\"description\":\"<p>saddsadsaddsa<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"3\",\"amenities\":\"asdsaddsa\",\"property_type\":\"sadsadsda\",\"token\":\"saddsad\",\"location\":\"dsadsd\",\"status\":\"asddsa\",\"area\":\"sadsadsa\",\"bed\":\"2\",\"bath\":\"3\",\"garage\":\"4\",\"url\":\"asddsaasd\",\"_token\":\"cIReRaVjnFxaaOrWq0cJKljBwL6Si5Klk8LjzPpZ\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 13:46:10', '2022-12-24 13:46:10'),
(270, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 13:46:11', '2022-12-24 13:46:11'),
(271, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 13:46:32', '2022-12-24 13:46:32'),
(272, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"assadd\",\"description\":\"<p>sadsadd<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"3\",\"amenities\":\"asdasd\",\"property_type\":\"asdsasad\",\"token\":\"saddsadsa\",\"location\":\"saddsadsa\",\"status\":\"saddsa\",\"area\":\"dsadsadsadsa\",\"bed\":\"3\",\"bath\":\"3\",\"garage\":\"3\",\"url\":\"saddsadssaddsa\",\"_token\":\"cIReRaVjnFxaaOrWq0cJKljBwL6Si5Klk8LjzPpZ\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 13:46:55', '2022-12-24 13:46:55'),
(273, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"assadd\",\"description\":\"<p>sadsadd<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"3\",\"amenities\":\"asdasd\",\"property_type\":\"asdsasad\",\"token\":\"saddsadsa\",\"location\":\"saddsadsa\",\"status\":\"saddsa\",\"area\":\"dsadsadsadsa\",\"bed\":\"3\",\"bath\":\"3\",\"garage\":\"3\",\"url\":\"saddsadssaddsa\",\"_token\":\"cIReRaVjnFxaaOrWq0cJKljBwL6Si5Klk8LjzPpZ\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 13:47:00', '2022-12-24 13:47:00'),
(274, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"assadd\",\"description\":\"<p>sadsadd<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"3\",\"amenities\":\"asdasd\",\"property_type\":\"asdsasad\",\"token\":\"saddsadsa\",\"location\":\"saddsadsa\",\"status\":\"saddsa\",\"area\":\"dsadsadsadsa\",\"bed\":\"3\",\"bath\":\"3\",\"garage\":\"3\",\"url\":\"saddsadssaddsa\",\"_token\":\"cIReRaVjnFxaaOrWq0cJKljBwL6Si5Klk8LjzPpZ\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 13:47:04', '2022-12-24 13:47:04'),
(275, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"assadd\",\"description\":\"<p>sadsadd<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"3\",\"amenities\":\"asdasd\",\"property_type\":\"asdsasad\",\"token\":\"saddsadsa\",\"location\":\"saddsadsa\",\"status\":\"saddsa\",\"area\":\"dsadsadsadsa\",\"bed\":\"3\",\"bath\":\"3\",\"garage\":\"3\",\"url\":\"saddsadssaddsa\",\"_token\":\"cIReRaVjnFxaaOrWq0cJKljBwL6Si5Klk8LjzPpZ\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 13:47:06', '2022-12-24 13:47:06'),
(276, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"assadd\",\"description\":\"<p>sadsadd<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"3\",\"amenities\":\"asdasd\",\"property_type\":\"asdsasad\",\"token\":\"saddsadsa\",\"location\":\"saddsadsa\",\"status\":\"saddsa\",\"area\":\"dsadsadsadsa\",\"bed\":\"3\",\"bath\":\"3\",\"garage\":\"3\",\"url\":\"saddsadssaddsa\",\"_token\":\"cIReRaVjnFxaaOrWq0cJKljBwL6Si5Klk8LjzPpZ\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 13:47:25', '2022-12-24 13:47:25'),
(277, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"assadd\",\"description\":\"<p>sadsadd<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"3\",\"amenities\":\"asdasd\",\"property_type\":\"asdsasad\",\"token\":\"saddsadsa\",\"location\":\"saddsadsa\",\"status\":\"saddsa\",\"area\":\"dsadsadsadsa\",\"bed\":\"3\",\"bath\":\"3\",\"garage\":\"3\",\"url\":\"saddsadssaddsa\",\"_token\":\"cIReRaVjnFxaaOrWq0cJKljBwL6Si5Klk8LjzPpZ\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 13:47:26', '2022-12-24 13:47:26'),
(278, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"assadd\",\"description\":\"<p>sadsadd<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"3\",\"amenities\":\"asdasd\",\"property_type\":\"asdsasad\",\"token\":\"saddsadsa\",\"location\":\"saddsadsa\",\"status\":\"saddsa\",\"area\":\"dsadsadsadsa\",\"bed\":\"3\",\"bath\":\"3\",\"garage\":\"3\",\"url\":\"saddsadssaddsa\",\"_token\":\"cIReRaVjnFxaaOrWq0cJKljBwL6Si5Klk8LjzPpZ\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 13:47:39', '2022-12-24 13:47:39'),
(279, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 13:47:41', '2022-12-24 13:47:41'),
(280, 1, 'admin/properties/11/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 13:49:27', '2022-12-24 13:49:27'),
(281, 1, 'admin/properties/11/edit', 'GET', '127.0.0.1', '[]', '2022-12-24 13:50:50', '2022-12-24 13:50:50'),
(282, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 13:51:05', '2022-12-24 13:51:05'),
(283, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 13:54:00', '2022-12-24 13:54:00'),
(284, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 13:54:21', '2022-12-24 13:54:21'),
(285, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"z\\\\xz\\\\\",\"description\":\"<p>x\\\\zx<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"2\",\"amenities\":\"dsfdsf\",\"property_type\":\"dsff\",\"token\":\"sdfsf\",\"location\":\"sdfsf\",\"status\":\"sdfdsf\",\"area\":\"sdfdsf\",\"bed\":\"3\",\"bath\":\"2\",\"garage\":\"2\",\"url\":\"dsfdsff\",\"_token\":\"cIReRaVjnFxaaOrWq0cJKljBwL6Si5Klk8LjzPpZ\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 14:02:29', '2022-12-24 14:02:29'),
(286, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-24 14:02:29', '2022-12-24 14:02:29'),
(287, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"z\\\\xz\\\\\",\"description\":\"<p>x\\\\zx<\\/p>\\r\\n\\r\\n<p>&nbsp;<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"2\",\"amenities\":\"dsfdsf\",\"property_type\":\"dsff\",\"token\":\"sdfsf\",\"location\":\"sdfsf\",\"status\":\"sdfdsf\",\"area\":\"sdfdsf\",\"bed\":\"3\",\"bath\":\"2\",\"garage\":\"2\",\"url\":\"dsfdsff\",\"_token\":\"cIReRaVjnFxaaOrWq0cJKljBwL6Si5Klk8LjzPpZ\"}', '2022-12-24 14:02:44', '2022-12-24 14:02:44');
INSERT INTO `admin_operation_log` (`id`, `user_id`, `path`, `method`, `ip`, `input`, `created_at`, `updated_at`) VALUES
(288, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-24 14:02:45', '2022-12-24 14:02:45'),
(289, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-24 14:04:15', '2022-12-24 14:04:15'),
(290, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 14:04:17', '2022-12-24 14:04:17'),
(291, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 14:04:18', '2022-12-24 14:04:18'),
(292, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 14:04:21', '2022-12-24 14:04:21'),
(293, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 14:06:52', '2022-12-24 14:06:52'),
(294, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 14:12:20', '2022-12-24 14:12:20'),
(295, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 14:12:53', '2022-12-24 14:12:53'),
(296, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 14:20:01', '2022-12-24 14:20:01'),
(297, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 14:28:15', '2022-12-24 14:28:15'),
(298, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 14:30:35', '2022-12-24 14:30:35'),
(299, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 14:33:27', '2022-12-24 14:33:27'),
(300, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"dfdsfs\",\"description\":\"<p>sddsfs<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"2\",\"amenities\":\"sddsfsfd\",\"property_type\":\"sdfsfds\",\"token\":\"dsffds\",\"location\":\"sdfsfds\",\"status\":\"dsffdsfds\",\"area\":\"dsfdfd\",\"bed\":\"2\",\"bath\":\"2\",\"garage\":\"2\",\"url\":\"dsffdsfsfds\",\"_token\":\"cIReRaVjnFxaaOrWq0cJKljBwL6Si5Klk8LjzPpZ\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 14:33:55', '2022-12-24 14:33:55'),
(301, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 14:33:55', '2022-12-24 14:33:55'),
(302, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 14:37:41', '2022-12-24 14:37:41'),
(303, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 14:45:13', '2022-12-24 14:45:13'),
(304, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 14:45:42', '2022-12-24 14:45:42'),
(305, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 14:45:44', '2022-12-24 14:45:44'),
(306, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"xzczxc\",\"description\":\"<p>xzccxz<\\/p>\\r\\n<quillbot-extension-portal><\\/quillbot-extension-portal>\",\"price\":\"3\",\"amenities\":\"zxcxc\",\"property_type\":\"xzcxx\",\"token\":\"xzcxcz\",\"location\":\"xzccx\",\"status\":\"xzccxz\",\"area\":\"xzcz\",\"bed\":\"4\",\"bath\":\"2\",\"garage\":\"2\",\"url\":\"xzcxccxxc\",\"_token\":\"cIReRaVjnFxaaOrWq0cJKljBwL6Si5Klk8LjzPpZ\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2022-12-24 14:46:05', '2022-12-24 14:46:05'),
(307, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 14:46:05', '2022-12-24 14:46:05'),
(308, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-24 14:46:05', '2022-12-24 14:46:05'),
(309, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2022-12-24 15:04:15', '2022-12-24 15:04:15'),
(310, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2022-12-24 15:04:19', '2022-12-24 15:04:19'),
(311, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 15:05:24', '2022-12-24 15:05:24'),
(312, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 15:23:04', '2022-12-24 15:23:04'),
(313, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2022-12-24 15:27:11', '2022-12-24 15:27:11'),
(314, 1, 'admin', 'GET', '127.0.0.1', '[]', '2023-01-02 01:52:52', '2023-01-02 01:52:52'),
(315, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-02 01:52:55', '2023-01-02 01:52:55'),
(316, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-02 01:52:57', '2023-01-02 01:52:57'),
(317, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-02 01:53:02', '2023-01-02 01:53:02'),
(318, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"this is the title\",\"description\":\"<p>this is the description part<\\/p>\",\"price\":\"4\",\"amenities\":\"amenities\",\"property_type\":\"prop_type one\",\"token\":\"3u34u348u3409\",\"location\":\"accra\",\"status\":\"dasfdfasdfdf\",\"area\":\"adfdffd\",\"bed\":\"2\",\"bath\":\"3\",\"garage\":\"3\",\"url\":\"adfadf\",\"_token\":\"3xdLwxTj92ZRQAvSDpGRiMXP0N6hF835ZbhgPn2x\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-02 01:57:58', '2023-01-02 01:57:58'),
(319, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 01:57:58', '2023-01-02 01:57:58'),
(320, 1, 'admin/properties/13/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-02 01:58:06', '2023-01-02 01:58:06'),
(321, 1, 'admin/properties/13/edit', 'GET', '127.0.0.1', '[]', '2023-01-02 01:58:42', '2023-01-02 01:58:42'),
(322, 1, 'admin/properties/13', 'PUT', '127.0.0.1', '{\"title\":\"xzczxc\",\"description\":\"<p>xzccxz<\\/p>\\r\\n\\r\\n<p>&nbsp;<\\/p>\",\"price\":\"3\",\"amenities\":\"zxcxc\",\"property_type\":\"xzcxx\",\"token\":\"xzcxcz\",\"location\":\"xzccx\",\"status\":\"xzccxz\",\"area\":\"xzcz\",\"bed\":\"4\",\"bath\":\"2\",\"garage\":\"2\",\"url\":\"xzcxccxxc\",\"_token\":\"3xdLwxTj92ZRQAvSDpGRiMXP0N6hF835ZbhgPn2x\",\"_method\":\"PUT\"}', '2023-01-02 01:58:47', '2023-01-02 01:58:47'),
(323, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 01:58:47', '2023-01-02 01:58:47'),
(324, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 07:35:58', '2023-01-02 07:35:58'),
(325, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-02 07:36:01', '2023-01-02 07:36:01'),
(326, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-02 07:44:42', '2023-01-02 07:44:42'),
(327, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-02 07:44:49', '2023-01-02 07:44:49'),
(328, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-02 07:44:50', '2023-01-02 07:44:50'),
(329, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-02 07:44:50', '2023-01-02 07:44:50'),
(330, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-02 07:44:52', '2023-01-02 07:44:52'),
(331, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"sdfsdfsdf\",\"description\":\"<p>sdffsdff<\\/p>\",\"price\":\"4\",\"amenities\":\"dsasdff\",\"url\":\"asdfafafaf\",\"_token\":\"9eg3LbchFGMnptsjerd5VIkFDN0wFDc6FduM0ypz\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-02 07:45:14', '2023-01-02 07:45:14'),
(332, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-02 07:45:14', '2023-01-02 07:45:14'),
(333, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-02 07:45:44', '2023-01-02 07:45:44'),
(334, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"sddfsdf\",\"description\":\"<p>xzccxz<\\/p>\\r\\n\\r\\n<p>&nbsp;<\\/p>\",\"price\":\"4\",\"amenities\":\"asdfdf\",\"url\":\"dfdadfs\",\"location\":\"dasfdfasdf\",\"_token\":\"9eg3LbchFGMnptsjerd5VIkFDN0wFDc6FduM0ypz\"}', '2023-01-02 07:45:58', '2023-01-02 07:45:58'),
(335, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 07:45:58', '2023-01-02 07:45:58'),
(336, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 07:46:52', '2023-01-02 07:46:52'),
(337, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 07:52:08', '2023-01-02 07:52:08'),
(338, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 07:54:47', '2023-01-02 07:54:47'),
(339, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 07:59:55', '2023-01-02 07:59:55'),
(340, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 08:04:51', '2023-01-02 08:04:51'),
(341, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 08:14:20', '2023-01-02 08:14:20'),
(342, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 08:14:32', '2023-01-02 08:14:32'),
(343, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 08:16:17', '2023-01-02 08:16:17'),
(344, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 08:16:44', '2023-01-02 08:16:44'),
(345, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 08:17:09', '2023-01-02 08:17:09'),
(346, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 08:18:02', '2023-01-02 08:18:02'),
(347, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 08:23:31', '2023-01-02 08:23:31'),
(348, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-02 08:23:33', '2023-01-02 08:23:33'),
(349, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"asdasdasd\",\"description\":\"asdsadsad\",\"price\":\"3\",\"amenities\":\"asdasdasd\",\"url\":\"sasd\",\"location\":\"asd\",\"_token\":\"9eg3LbchFGMnptsjerd5VIkFDN0wFDc6FduM0ypz\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-02 08:23:55', '2023-01-02 08:23:55'),
(350, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-02 08:23:55', '2023-01-02 08:23:55'),
(351, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-02 08:24:31', '2023-01-02 08:24:31'),
(352, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-02 08:24:34', '2023-01-02 08:24:34'),
(353, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"asdfa\",\"description\":\"asdfasdf\",\"price\":\"2\",\"amenities\":\"afaff\",\"url\":\"asdfdf\",\"location\":\"dfdadfs\",\"_token\":\"9eg3LbchFGMnptsjerd5VIkFDN0wFDc6FduM0ypz\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-02 08:24:45', '2023-01-02 08:24:45'),
(354, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 08:24:45', '2023-01-02 08:24:45'),
(355, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 08:26:53', '2023-01-02 08:26:53'),
(356, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 08:27:52', '2023-01-02 08:27:52'),
(357, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 08:32:21', '2023-01-02 08:32:21'),
(358, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 08:32:44', '2023-01-02 08:32:44'),
(359, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 08:32:59', '2023-01-02 08:32:59'),
(360, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 08:35:07', '2023-01-02 08:35:07'),
(361, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-02 08:41:18', '2023-01-02 08:41:18'),
(362, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"Two Bedroom Osu\",\"description\":\"Spacious rooms, compared to most new developments in Ghana, sets us apart from others. We are very precious about ensuring that our rooms are functional and generously proportioned.\\r\\n                  Total Internal Square Meters \\u2013 202m2\\r\\n                  This includes foyer, living room, dining room, kitchen, utility, pantry, Three bedroom en-suite and one master bedroom en-suite, walk-in-wardrobe, closet area, visitors powder room.\\r\\n                  Measurement excludes porch, veranda and carport.\",\"price\":\"4000\",\"amenities\":\"amen1\",\"url\":\"url\",\"location\":\"tarkwa\",\"_token\":\"9eg3LbchFGMnptsjerd5VIkFDN0wFDc6FduM0ypz\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-02 08:43:39', '2023-01-02 08:43:39'),
(363, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 08:43:39', '2023-01-02 08:43:39'),
(364, 1, 'admin/properties/2/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-02 08:49:39', '2023-01-02 08:49:39'),
(365, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-02 15:41:33', '2023-01-02 15:41:33'),
(366, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-02 16:18:24', '2023-01-02 16:18:24'),
(367, 1, 'admin/_handle_action_', 'POST', '127.0.0.1', '{\"_key\":\"2\",\"_model\":\"App_Models_Property\",\"_token\":\"9VV43Jq9h0MGL9AOAd0RQDIo4BbYMdJqDZFy26TV\",\"_action\":\"Encore_Admin_Grid_Actions_Delete\",\"_input\":\"true\"}', '2023-01-02 16:18:30', '2023-01-02 16:18:30'),
(368, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-02 16:18:30', '2023-01-02 16:18:30'),
(369, 1, 'admin/_handle_action_', 'POST', '127.0.0.1', '{\"_key\":\"3\",\"_model\":\"App_Models_Property\",\"_token\":\"9VV43Jq9h0MGL9AOAd0RQDIo4BbYMdJqDZFy26TV\",\"_action\":\"Encore_Admin_Grid_Actions_Delete\",\"_input\":\"true\"}', '2023-01-02 16:18:35', '2023-01-02 16:18:35'),
(370, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-02 16:18:35', '2023-01-02 16:18:35'),
(371, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-02 16:18:43', '2023-01-02 16:18:43'),
(372, 1, 'admin', 'GET', '127.0.0.1', '[]', '2023-01-03 17:43:34', '2023-01-03 17:43:34'),
(373, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 17:43:38', '2023-01-03 17:43:38'),
(374, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 17:44:11', '2023-01-03 17:44:11'),
(375, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"this is the title\",\"description\":\"this is the content\",\"price\":\"4\",\"amenities\":\"amen1\",\"url\":\"url\",\"location\":\"location 1\",\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-03 17:53:33', '2023-01-03 17:53:33'),
(376, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 17:53:33', '2023-01-03 17:53:33'),
(377, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 17:53:50', '2023-01-03 17:53:50'),
(378, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 17:57:14', '2023-01-03 17:57:14'),
(379, 1, 'admin', 'GET', '127.0.0.1', '[]', '2023-01-03 18:00:08', '2023-01-03 18:00:08'),
(380, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 18:00:10', '2023-01-03 18:00:10'),
(381, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 18:00:24', '2023-01-03 18:00:24'),
(382, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 18:00:27', '2023-01-03 18:00:27'),
(383, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 18:00:28', '2023-01-03 18:00:28'),
(384, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 18:00:35', '2023-01-03 18:00:35'),
(385, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"this is the title\",\"description\":\"aasas\",\"price\":\"10\",\"amenities\":\"asdasdasd\",\"url\":\"url\",\"location\":\"the location\",\"_file_sort_\":{\"pictures\":null},\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-03 18:01:14', '2023-01-03 18:01:14'),
(386, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 18:01:14', '2023-01-03 18:01:14'),
(387, 1, 'admin/_handle_action_', 'POST', '127.0.0.1', '{\"_key\":\"4\",\"_model\":\"App_Models_Property\",\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\",\"_action\":\"Encore_Admin_Grid_Actions_Delete\",\"_input\":\"true\"}', '2023-01-03 18:23:28', '2023-01-03 18:23:28'),
(388, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 18:23:28', '2023-01-03 18:23:28'),
(389, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 18:23:31', '2023-01-03 18:23:31'),
(390, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"erwerer\",\"description\":\"werweer\",\"price\":\"6\",\"amenities\":\"werwer\",\"url\":\"were\",\"location\":\"location\",\"_file_sort_\":{\"pictures\":null},\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-03 18:23:59', '2023-01-03 18:23:59'),
(391, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 18:23:59', '2023-01-03 18:23:59'),
(392, 1, 'admin/properties/6/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 21:13:14', '2023-01-03 21:13:14'),
(393, 1, 'admin/properties/6', 'PUT', '127.0.0.1', '{\"title\":\"erwerer\",\"description\":\"werweer\",\"price\":\"6\",\"amenities\":\"werwerwerwerwerwerwe rwerwerwerwerwerwerwerwerwer werwerwerwerwerwerwerwerw      erwerwerwerwerwerwerwerw      erwerwerwerwerwerwerwerwerwerwerwerwerwer\",\"url\":\"were\",\"location\":\"location\",\"_file_sort_\":{\"pictures\":null},\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-03 21:13:32', '2023-01-03 21:13:32'),
(394, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 21:13:32', '2023-01-03 21:13:32'),
(395, 1, 'admin/properties/5/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 21:15:32', '2023-01-03 21:15:32'),
(396, 1, 'admin/properties/5', 'PUT', '127.0.0.1', '{\"title\":\"this is the title\",\"description\":\"aasas\",\"price\":\"10\",\"amenities\":\"asdasdasd,  asdasdasd, asdasdasd asdasdasd asdasdasd asdasdasd asdasdasdasdasdasd\",\"url\":\"url\",\"location\":\"the location\",\"_file_sort_\":{\"pictures\":null},\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-03 21:15:50', '2023-01-03 21:15:50'),
(397, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 21:15:50', '2023-01-03 21:15:50'),
(398, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 21:19:26', '2023-01-03 21:19:26'),
(399, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 21:19:28', '2023-01-03 21:19:28'),
(400, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"ASDASDASD\",\"description\":\"ASDASASD\",\"price\":\"5\",\"url\":\"ASDSDSD\",\"location\":\"ADASD\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"1\",\"2\",null],\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-03 21:20:57', '2023-01-03 21:20:57'),
(401, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-03 21:20:57', '2023-01-03 21:20:57'),
(402, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-03 21:26:25', '2023-01-03 21:26:25'),
(403, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-03 21:26:30', '2023-01-03 21:26:30'),
(404, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-03 21:27:00', '2023-01-03 21:27:00'),
(405, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"asdasdd\",\"description\":\"sadasdasd\",\"price\":\"5\",\"url\":\"asadsasd\",\"location\":\"asdasd\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"2\",\"val\",null],\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\"}', '2023-01-03 21:27:18', '2023-01-03 21:27:18'),
(406, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-03 21:27:18', '2023-01-03 21:27:18'),
(407, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"asdasdd\",\"description\":\"sadasdasd\",\"price\":\"5\",\"url\":\"asadsasd\",\"location\":\"asdasd\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"2\",\"val\",null],\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\"}', '2023-01-03 21:28:20', '2023-01-03 21:28:20'),
(408, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-03 21:28:20', '2023-01-03 21:28:20'),
(409, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-03 21:28:23', '2023-01-03 21:28:23'),
(410, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"asdasdd\",\"description\":\"sadasdasd\",\"price\":null,\"url\":\"asadsasd\",\"location\":\"asdasd\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"2\",\"val\",null],\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\"}', '2023-01-03 21:28:26', '2023-01-03 21:28:26'),
(411, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-03 21:28:26', '2023-01-03 21:28:26'),
(412, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-03 21:31:44', '2023-01-03 21:31:44'),
(413, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-03 21:31:47', '2023-01-03 21:31:47'),
(414, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"asdasdd\",\"description\":\"sadasdasd\",\"price\":null,\"url\":\"asadsasd\",\"location\":\"asdasd\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"2\",\"val\",null],\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\"}', '2023-01-03 21:31:49', '2023-01-03 21:31:49'),
(415, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-03 21:31:49', '2023-01-03 21:31:49'),
(416, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-03 21:34:47', '2023-01-03 21:34:47'),
(417, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"asdasdd\",\"description\":\"sadasdasd\",\"price\":\"4\",\"url\":\"asadsasd\",\"location\":\"asdasd\",\"area\":\"sdfgdsf\",\"bed\":\"2\",\"bath\":\"2\",\"kitchen\":\"2\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"1\",\"val\",null],\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\"}', '2023-01-03 21:35:09', '2023-01-03 21:35:09'),
(418, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 21:35:09', '2023-01-03 21:35:09'),
(419, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 21:42:15', '2023-01-03 21:42:15'),
(420, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 21:42:45', '2023-01-03 21:42:45'),
(421, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"adfa\",\"description\":\"asdasd\",\"price\":\"5\",\"url\":\"asdasdd\",\"location\":\"asdas\",\"area\":\"asdasdsda\",\"bed\":\"5\",\"bath\":\"3\",\"kitchen\":\"4\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"0\",\"2\",\"4\",null],\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-03 21:43:35', '2023-01-03 21:43:35'),
(422, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 21:43:35', '2023-01-03 21:43:35'),
(423, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 21:46:35', '2023-01-03 21:46:35'),
(424, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 21:47:11', '2023-01-03 21:47:11'),
(425, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 21:47:14', '2023-01-03 21:47:14'),
(426, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"wewerewrwerwer\",\"description\":\"wewerwer\",\"price\":\"4\",\"url\":\"qwerqwewer\",\"location\":\"323434\",\"area\":\"adfdffd\",\"bed\":\"5\",\"bath\":\"3\",\"kitchen\":\"3\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Cable Tv\",\"Tennis Courts\",null],\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-03 21:47:51', '2023-01-03 21:47:51'),
(427, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 21:47:51', '2023-01-03 21:47:51'),
(428, 1, 'admin/properties/9/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 21:51:37', '2023-01-03 21:51:37'),
(429, 1, 'admin/properties/9', 'PUT', '127.0.0.1', '{\"title\":\"wewerewrwerwer\",\"description\":\"wewerwer\",\"price\":\"4\",\"url\":\"qwerqwewer\",\"location\":\"323434\",\"area\":\"adfdffd\",\"bed\":\"5\",\"bath\":\"3\",\"kitchen\":\"3\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Balcony\",\"Outdoor Kitchen\",\"Cable Tv\",\"Deck\",\"Tennis Courts\",\"Internet\",\"Parking\",\"fenced\",\"Sun Room\",\"Concrete Flooring\",null],\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-03 21:52:43', '2023-01-03 21:52:43'),
(430, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 21:52:43', '2023-01-03 21:52:43'),
(431, 1, 'admin/_handle_action_', 'POST', '127.0.0.1', '{\"_key\":\"5\",\"_model\":\"App_Models_Property\",\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\",\"_action\":\"Encore_Admin_Grid_Actions_Delete\",\"_input\":\"true\"}', '2023-01-03 21:54:33', '2023-01-03 21:54:33'),
(432, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 21:54:33', '2023-01-03 21:54:33'),
(433, 1, 'admin/properties/6,7,8,9', 'DELETE', '127.0.0.1', '{\"_method\":\"delete\",\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\"}', '2023-01-03 21:54:40', '2023-01-03 21:54:40'),
(434, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 21:54:40', '2023-01-03 21:54:40'),
(435, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 21:54:43', '2023-01-03 21:54:43'),
(436, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"sfdfgsdf\",\"description\":\"adfasdf\",\"price\":\"3\",\"url\":\"dfsdf\",\"location\":\"dfdsf\",\"area\":\"dfsdf\",\"bed\":\"3\",\"bath\":\"2\",\"kitchen\":\"3\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Balcony\",\"Tiled\",\"Kitchen\",\"Tv\",\"Deck\",\"Internet\",\"fenced\",\"Concrete_Flooring\",null],\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-03 21:55:25', '2023-01-03 21:55:25'),
(437, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 21:55:25', '2023-01-03 21:55:25'),
(438, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 21:58:05', '2023-01-03 21:58:05'),
(439, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 22:00:20', '2023-01-03 22:00:20'),
(440, 1, 'admin', 'GET', '127.0.0.1', '[]', '2023-01-03 22:58:09', '2023-01-03 22:58:09'),
(441, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 22:58:18', '2023-01-03 22:58:18'),
(442, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 22:58:23', '2023-01-03 22:58:23'),
(443, 1, 'admin', 'GET', '127.0.0.1', '[]', '2023-01-03 23:14:09', '2023-01-03 23:14:09'),
(444, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 23:14:12', '2023-01-03 23:14:12'),
(445, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 23:14:14', '2023-01-03 23:14:14'),
(446, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"sdvdsd\",\"description\":\"vsdv\",\"price\":\"3\",\"url\":\"zxczc\",\"location\":\"zczxc\",\"area\":\"zxccxcx\",\"bed\":\"4\",\"bath\":\"3\",\"kitchen\":\"2\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Kitchen\",\"Deck\",null],\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-03 23:14:40', '2023-01-03 23:14:40'),
(447, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 23:14:40', '2023-01-03 23:14:40'),
(448, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 23:14:43', '2023-01-03 23:14:43'),
(449, 1, 'admin', 'GET', '127.0.0.1', '[]', '2023-01-03 23:17:11', '2023-01-03 23:17:11'),
(450, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 23:17:13', '2023-01-03 23:17:13'),
(451, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 23:17:15', '2023-01-03 23:17:15'),
(452, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"asdsdsd\",\"description\":\"asdasdas\",\"price\":\"2\",\"url\":\"asdsa\",\"location\":\"asdasd\",\"area\":\"asdsda\",\"bed\":\"2\",\"bath\":\"2\",\"kitchen\":\"2\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Kitchen\",\"Deck\",\"Tennis_Courts\",null],\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-03 23:17:39', '2023-01-03 23:17:39'),
(453, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 23:17:39', '2023-01-03 23:17:39'),
(454, 1, 'admin', 'GET', '127.0.0.1', '[]', '2023-01-03 23:19:12', '2023-01-03 23:19:12'),
(455, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 23:19:14', '2023-01-03 23:19:14'),
(456, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 23:21:19', '2023-01-03 23:21:19'),
(457, 1, 'admin/properties/10/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 23:45:20', '2023-01-03 23:45:20'),
(458, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 23:45:25', '2023-01-03 23:45:25'),
(459, 1, 'admin/properties/11/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 23:45:28', '2023-01-03 23:45:28'),
(460, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 23:45:33', '2023-01-03 23:45:33'),
(461, 1, 'admin/properties/12/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 23:45:35', '2023-01-03 23:45:35'),
(462, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 23:45:41', '2023-01-03 23:45:41'),
(463, 1, 'admin/properties/10/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 23:45:45', '2023-01-03 23:45:45'),
(464, 1, 'admin/properties/10', 'PUT', '127.0.0.1', '{\"title\":\"sfdfgsdf\",\"description\":\"adfasdf\",\"price\":\"3\",\"url\":\"https:\\/\\/www.google.com\\/maps\\/embed?pb=!1m18!1m12!1m3!1d3971.0617539972113!2d-0.3090868852340717!3d5.557865395970324!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdfbd524a2cf521%3A0x3728a17474c32bfe!2sGa%20South%20District%20Magistrate%20Court!5e0!3m2!1sen!2sgh!4v1671150181862!5m2!1sen!2sgh\\\" width=\\\"600\\\" height=\\\"450\\\" style=\\\"border:0;\\\" allowfullscreen=\\\"\\\" loading=\\\"lazy\\\" referrerpolicy=\\\"no-referrer-when-downgrade\",\"location\":\"dfdsf\",\"area\":\"dfsdf\",\"bed\":\"3\",\"bath\":\"2\",\"kitchen\":\"3\",\"_file_sort_\":{\"pictures\":\"1,0,2,3,4\"},\"amenities\":[\"Balcony\",\"Tiled\",\"Kitchen\",\"Tv\",\"Deck\",\"Internet\",\"fenced\",\"Concrete_Flooring\",null],\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-03 23:45:58', '2023-01-03 23:45:58'),
(465, 1, 'admin/properties/10/edit', 'GET', '127.0.0.1', '[]', '2023-01-03 23:45:59', '2023-01-03 23:45:59'),
(466, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 23:46:18', '2023-01-03 23:46:18'),
(467, 1, 'admin/_handle_action_', 'POST', '127.0.0.1', '{\"_key\":\"10\",\"_model\":\"App_Models_Property\",\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\",\"_action\":\"Encore_Admin_Grid_Actions_Delete\",\"_input\":\"true\"}', '2023-01-03 23:46:24', '2023-01-03 23:46:24'),
(468, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 23:46:24', '2023-01-03 23:46:24'),
(469, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-03 23:46:26', '2023-01-03 23:46:26'),
(470, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"sdffdf\",\"description\":\"sdfsd\",\"price\":\"3\",\"url\":\"sdfdf\",\"location\":\"sdff\",\"area\":\"sdfdf\",\"bed\":\"1\",\"bath\":\"1\",\"kitchen\":\"2\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Tv\",\"Tennis_Courts\",null],\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-03 23:46:59', '2023-01-03 23:46:59'),
(471, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-03 23:46:59', '2023-01-03 23:46:59'),
(472, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-04 00:38:03', '2023-01-04 00:38:03'),
(473, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-04 00:38:04', '2023-01-04 00:38:04'),
(474, 1, 'admin/properties/11,12,13', 'DELETE', '127.0.0.1', '{\"_method\":\"delete\",\"_token\":\"KGqUti6yf2iBOIRthdEKhKXa9VCOIwL2QMjcC9dt\"}', '2023-01-04 00:38:09', '2023-01-04 00:38:09'),
(475, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-04 00:38:09', '2023-01-04 00:38:09'),
(476, 1, 'admin', 'GET', '127.0.0.1', '[]', '2023-01-18 04:43:32', '2023-01-18 04:43:32'),
(477, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 04:46:22', '2023-01-18 04:46:22'),
(478, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 04:46:27', '2023-01-18 04:46:27'),
(479, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"dsfsdfsdffds\",\"description\":\"dsfdsf\",\"price\":\"3\",\"url\":\"zxxxz\",\"location\":\"dsfdfsdf\",\"area\":\"saddsadsa\",\"bed\":\"1\",\"bath\":\"2\",\"kitchen\":\"1\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Kitchen\",\"Tennis_Courts\",null],\"_token\":\"E4Lf90Szvr5v4l0e0AlovfDOcNXVxQSQL5EouZSB\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-18 05:00:34', '2023-01-18 05:00:34'),
(480, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-18 05:00:35', '2023-01-18 05:00:35'),
(481, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-18 05:17:40', '2023-01-18 05:17:40'),
(482, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"xzccxzcxzcxzcx\",\"description\":\"cxzccx\",\"price\":\"3\",\"url\":\"asddsadsdsasd\",\"location\":\"asdsdadsa\",\"area\":\"saddsadsa\",\"bed\":\"3\",\"bath\":\"2\",\"kitchen\":\"2\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Kitchen\",\"Tennis_Courts\",null],\"_token\":\"E4Lf90Szvr5v4l0e0AlovfDOcNXVxQSQL5EouZSB\"}', '2023-01-18 05:18:12', '2023-01-18 05:18:12'),
(483, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-18 05:18:12', '2023-01-18 05:18:12'),
(484, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"xzccxzcxzcxzcx\",\"description\":\"cxzccx\",\"price\":\"3\",\"url\":\"asddsadsdsasd\",\"location\":\"asdsdadsa\",\"area\":\"saddsadsa\",\"bed\":\"3\",\"bath\":\"2\",\"kitchen\":\"2\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Kitchen\",\"Tennis_Courts\",null],\"_token\":\"E4Lf90Szvr5v4l0e0AlovfDOcNXVxQSQL5EouZSB\"}', '2023-01-18 05:20:10', '2023-01-18 05:20:10'),
(485, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-18 05:20:11', '2023-01-18 05:20:11'),
(486, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"xzccxzcxzcxzcx\",\"description\":\"cxzccx\",\"price\":\"3\",\"url\":\"asddsadsdsasd\",\"location\":\"asdsdadsa\",\"area\":\"saddsadsa\",\"bed\":\"3\",\"bath\":\"2\",\"kitchen\":\"2\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Kitchen\",\"Tennis_Courts\",null],\"_token\":\"E4Lf90Szvr5v4l0e0AlovfDOcNXVxQSQL5EouZSB\"}', '2023-01-18 05:20:23', '2023-01-18 05:20:23'),
(487, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-18 05:20:24', '2023-01-18 05:20:24'),
(488, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 05:20:28', '2023-01-18 05:20:28'),
(489, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"asddsadsa\",\"description\":\"sadsd\",\"price\":\"4\",\"url\":\"sadds\",\"location\":\"asx\",\"area\":\"dsffd\",\"bed\":\"2\",\"bath\":\"2\",\"kitchen\":\"2\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Tv\",\"Tennis_Courts\",null],\"_token\":\"E4Lf90Szvr5v4l0e0AlovfDOcNXVxQSQL5EouZSB\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-18 05:20:54', '2023-01-18 05:20:54'),
(490, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-18 05:20:55', '2023-01-18 05:20:55'),
(491, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 05:20:58', '2023-01-18 05:20:58'),
(492, 1, 'admin/properties', 'POST', '127.0.0.1', '{\"title\":\"asddsa\",\"description\":\"sadsadsad\",\"price\":\"5\",\"url\":\"asddsadsdsasd\",\"location\":\"asdsdadsa\",\"area\":\"asddsa\",\"bed\":\"5\",\"bath\":\"3\",\"kitchen\":\"4\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Tv\",\"Deck\",\"Tennis_Courts\",null],\"_token\":\"E4Lf90Szvr5v4l0e0AlovfDOcNXVxQSQL5EouZSB\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-18 05:21:53', '2023-01-18 05:21:53'),
(493, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-18 05:21:53', '2023-01-18 05:21:53'),
(494, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-18 05:22:03', '2023-01-18 05:22:03'),
(495, 1, 'admin', 'GET', '127.0.0.1', '[]', '2023-01-18 08:50:02', '2023-01-18 08:50:02'),
(496, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 08:50:06', '2023-01-18 08:50:06'),
(497, 1, 'admin/properties/create', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 08:50:10', '2023-01-18 08:50:10'),
(498, 1, 'admin/properties/create', 'GET', '127.0.0.1', '[]', '2023-01-18 08:50:46', '2023-01-18 08:50:46'),
(499, 1, 'admin', 'GET', '127.0.0.1', '[]', '2023-01-18 17:22:09', '2023-01-18 17:22:09'),
(500, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 17:22:16', '2023-01-18 17:22:16'),
(501, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 17:22:20', '2023-01-18 17:22:20'),
(502, 1, 'admin/properties/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 17:22:25', '2023-01-18 17:22:25'),
(503, 1, 'admin/properties/1', 'PUT', '127.0.0.1', '{\"title\":\"xzccxzcxzcxzcx\",\"description\":\"cxzccx\",\"price\":\"3\",\"url\":\"https:\\/\\/www.google.com\\/maps\\/embed?pb=!1m18!1m12!1m3!1d15884.066269034032!2d-0.2983689!3d5.5645614!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf981a8975e7bb%3A0xc4d4487298accf44!2sMcCarthy%20Hill%2C%20Mallam!5e0!3m2!1sen!2sgh!4v1674033679073!5m2!1sen!2sgh\",\"location\":\"asdsdadsa\",\"area\":\"saddsadsa\",\"bed\":\"3\",\"bath\":\"2\",\"kitchen\":\"2\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Kitchen\",null],\"_token\":\"NfLmuYpGwna8hxZrSqSpH4rXbtU4Xo96eSFyGPrC\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-18 17:22:34', '2023-01-18 17:22:34'),
(504, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-18 17:22:35', '2023-01-18 17:22:35'),
(505, 1, 'admin/properties/2/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 17:22:38', '2023-01-18 17:22:38'),
(506, 1, 'admin/properties/2', 'PUT', '127.0.0.1', '{\"title\":\"asddsadsa\",\"description\":\"sadsd\",\"price\":\"4\",\"url\":\"https:\\/\\/www.google.com\\/maps\\/embed?pb=!1m18!1m12!1m3!1d15884.066269034032!2d-0.2983689!3d5.5645614!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf981a8975e7bb%3A0xc4d4487298accf44!2sMcCarthy%20Hill%2C%20Mallam!5e0!3m2!1sen!2sgh!4v1674033679073!5m2!1sen!2sgh\",\"location\":\"asx\",\"area\":\"dsffd\",\"bed\":\"2\",\"bath\":\"2\",\"kitchen\":\"2\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Tv\",null],\"_token\":\"NfLmuYpGwna8hxZrSqSpH4rXbtU4Xo96eSFyGPrC\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-18 17:22:47', '2023-01-18 17:22:47'),
(507, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-18 17:22:48', '2023-01-18 17:22:48'),
(508, 1, 'admin/properties/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 17:22:53', '2023-01-18 17:22:53'),
(509, 1, 'admin/properties/3', 'PUT', '127.0.0.1', '{\"title\":\"asddsa\",\"description\":\"sadsadsad\",\"price\":\"5\",\"url\":\"https:\\/\\/www.google.com\\/maps\\/embed?pb=!1m18!1m12!1m3!1d15884.066269034032!2d-0.2983689!3d5.5645614!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf981a8975e7bb%3A0xc4d4487298accf44!2sMcCarthy%20Hill%2C%20Mallam!5e0!3m2!1sen!2sgh!4v1674033679073!5m2!1sen!2sgh\",\"location\":\"asdsdadsa\",\"area\":\"asddsa\",\"bed\":\"5\",\"bath\":\"3\",\"kitchen\":\"4\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Tv\",null],\"_token\":\"NfLmuYpGwna8hxZrSqSpH4rXbtU4Xo96eSFyGPrC\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-18 17:22:59', '2023-01-18 17:22:59'),
(510, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-18 17:22:59', '2023-01-18 17:22:59'),
(511, 1, 'admin', 'GET', '127.0.0.1', '[]', '2023-01-18 17:28:13', '2023-01-18 17:28:13'),
(512, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 17:28:16', '2023-01-18 17:28:16'),
(513, 1, 'admin/properties/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 17:28:19', '2023-01-18 17:28:19'),
(514, 1, 'admin/properties/1', 'PUT', '127.0.0.1', '{\"title\":\"xzccxzcxzcxzcx\",\"description\":\"Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellat hic sunt pariatur omnis eum vero, incidunt facilis sapiente. Doloribus, accusamus. Rerum maxime consequuntur qui exercitationem quae corporis provident pariatur! Eveniet?\\r\\nConsectetur molestias reiciendis itaque cum magnam qui rerum facilis eos debitis nihil iste enim error quis nisi, aliquid natus non similique? Sequi quia cum ipsa voluptatibus, explicabo incidunt assumenda eaque!\\r\\nAtque repudiandae harum enim recusandae. Vel cum non doloribus odio labore facilis vero nobis saepe eius. Culpa voluptatum itaque porro maxime ex eos in, quod laudantium eveniet ducimus? Eos, possimus.\\r\\nDoloribus incidunt expedita corporis minima possimus. Ex atque error consequuntur architecto! Sint quidem aut voluptatum modi impedit laborum natus ea maiores ex tempore error laudantium explicabo est debitis, repellat velit.\\r\\nNam ex et aut hic magni nihil nobis minus architecto, id cumque harum facere voluptatibus molestias dolor porro facilis quaerat fugiat! Iusto ipsum veritatis adipisci est! Optio dignissimos quam corrupti?\",\"price\":\"3\",\"url\":\"https:\\/\\/www.google.com\\/maps\\/embed?pb=!1m18!1m12!1m3!1d15884.066269034032!2d-0.2983689!3d5.5645614!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf981a8975e7bb%3A0xc4d4487298accf44!2sMcCarthy%20Hill%2C%20Mallam!5e0!3m2!1sen!2sgh!4v1674033679073!5m2!1sen!2sgh\",\"location\":\"asdsdadsa\",\"area\":\"saddsadsa\",\"bed\":\"3\",\"bath\":\"2\",\"kitchen\":\"2\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Air condition\",\"Kitchen\",\"Tv\",\"Internet\",\"Security service\",\"fenced\",null],\"_token\":\"NfLmuYpGwna8hxZrSqSpH4rXbtU4Xo96eSFyGPrC\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-18 17:28:38', '2023-01-18 17:28:38'),
(515, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-18 17:28:38', '2023-01-18 17:28:38'),
(516, 1, 'admin/properties/2/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 17:28:43', '2023-01-18 17:28:43'),
(517, 1, 'admin/properties/2', 'PUT', '127.0.0.1', '{\"title\":\"asddsadsa\",\"description\":\"Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellat hic sunt pariatur omnis eum vero, incidunt facilis sapiente. Doloribus, accusamus. Rerum maxime consequuntur qui exercitationem quae corporis provident pariatur! Eveniet?\\r\\nConsectetur molestias reiciendis itaque cum magnam qui rerum facilis eos debitis nihil iste enim error quis nisi, aliquid natus non similique? Sequi quia cum ipsa voluptatibus, explicabo incidunt assumenda eaque!\\r\\nAtque repudiandae harum enim recusandae. Vel cum non doloribus odio labore facilis vero nobis saepe eius. Culpa voluptatum itaque porro maxime ex eos in, quod laudantium eveniet ducimus? Eos, possimus.\\r\\nDoloribus incidunt expedita corporis minima possimus. Ex atque error consequuntur architecto! Sint quidem aut voluptatum modi impedit laborum natus ea maiores ex tempore error laudantium explicabo est debitis, repellat velit.\\r\\nNam ex et aut hic magni nihil nobis minus architecto, id cumque harum facere voluptatibus molestias dolor porro facilis quaerat fugiat! Iusto ipsum veritatis adipisci est! Optio dignissimos quam corrupti?\",\"price\":\"4\",\"url\":\"https:\\/\\/www.google.com\\/maps\\/embed?pb=!1m18!1m12!1m3!1d15884.066269034032!2d-0.2983689!3d5.5645614!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf981a8975e7bb%3A0xc4d4487298accf44!2sMcCarthy%20Hill%2C%20Mallam!5e0!3m2!1sen!2sgh!4v1674033679073!5m2!1sen!2sgh\",\"location\":\"asx\",\"area\":\"dsffd\",\"bed\":\"2\",\"bath\":\"2\",\"kitchen\":\"2\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Air condition\",\"Tiled\",\"Tv\",\"Internet\",\"Security service\",null],\"_token\":\"NfLmuYpGwna8hxZrSqSpH4rXbtU4Xo96eSFyGPrC\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-18 17:28:54', '2023-01-18 17:28:54'),
(518, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-18 17:28:55', '2023-01-18 17:28:55'),
(519, 1, 'admin/properties/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 17:28:58', '2023-01-18 17:28:58'),
(520, 1, 'admin/properties/3', 'PUT', '127.0.0.1', '{\"title\":\"asddsa\",\"description\":\"Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellat hic sunt pariatur omnis eum vero, incidunt facilis sapiente. Doloribus, accusamus. Rerum maxime consequuntur qui exercitationem quae corporis provident pariatur! Eveniet?\\r\\nConsectetur molestias reiciendis itaque cum magnam qui rerum facilis eos debitis nihil iste enim error quis nisi, aliquid natus non similique? Sequi quia cum ipsa voluptatibus, explicabo incidunt assumenda eaque!\\r\\nAtque repudiandae harum enim recusandae. Vel cum non doloribus odio labore facilis vero nobis saepe eius. Culpa voluptatum itaque porro maxime ex eos in, quod laudantium eveniet ducimus? Eos, possimus.\\r\\nDoloribus incidunt expedita corporis minima possimus. Ex atque error consequuntur architecto! Sint quidem aut voluptatum modi impedit laborum natus ea maiores ex tempore error laudantium explicabo est debitis, repellat velit.\\r\\nNam ex et aut hic magni nihil nobis minus architecto, id cumque harum facere voluptatibus molestias dolor porro facilis quaerat fugiat! Iusto ipsum veritatis adipisci est! Optio dignissimos quam corrupti?\",\"price\":\"5\",\"url\":\"https:\\/\\/www.google.com\\/maps\\/embed?pb=!1m18!1m12!1m3!1d15884.066269034032!2d-0.2983689!3d5.5645614!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf981a8975e7bb%3A0xc4d4487298accf44!2sMcCarthy%20Hill%2C%20Mallam!5e0!3m2!1sen!2sgh!4v1674033679073!5m2!1sen!2sgh\",\"location\":\"asdsdadsa\",\"area\":\"asddsa\",\"bed\":\"5\",\"bath\":\"3\",\"kitchen\":\"4\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Tv\",\"Internet\",\"Water reservoir\",\"fenced\",\"Concrete_Flooring\",null],\"_token\":\"NfLmuYpGwna8hxZrSqSpH4rXbtU4Xo96eSFyGPrC\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-18 17:29:13', '2023-01-18 17:29:13'),
(521, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-18 17:29:13', '2023-01-18 17:29:13'),
(522, 1, 'admin/properties/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 17:30:09', '2023-01-18 17:30:09'),
(523, 1, 'admin/properties/1', 'PUT', '127.0.0.1', '{\"title\":\"xzccxzcxzcxzcx\",\"description\":\"Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellat hic sunt pariatur omnis eum vero, incidunt facilis sapiente. Doloribus, accusamus. Rerum maxime consequuntur qui exercitationem quae corporis provident pariatur! Eveniet?\\r\\nConsectetur molestias reiciendis itaque cum magnam qui rerum facilis eos debitis nihil iste enim error quis nisi, aliquid natus non similique? Sequi quia cum ipsa voluptatibus, explicabo incidunt assumenda eaque!\\r\\nAtque repudiandae harum enim recusandae. Vel cum non doloribus odio labore facilis vero nobis saepe eius. Culpa voluptatum itaque porro maxime ex eos in, quod laudantium eveniet ducimus? Eos, possimus.\\r\\nDoloribus incidunt expedita corporis minima possimus. Ex atque error consequuntur architecto! Sint quidem aut voluptatum modi impedit laborum natus ea maiores ex tempore error laudantium explicabo est debitis, repellat velit.\\r\\nNam ex et aut hic magni nihil nobis minus architecto, id cumque harum facere voluptatibus molestias dolor porro facilis quaerat fugiat! Iusto ipsum veritatis adipisci est! Optio dignissimos quam corrupti?\",\"price\":\"3\",\"url\":\"https:\\/\\/www.google.com\\/maps\\/embed?pb=!1m18!1m12!1m3!1d15884.066269034032!2d-0.2983689!3d5.5645614!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf981a8975e7bb%3A0xc4d4487298accf44!2sMcCarthy%20Hill%2C%20Mallam!5e0!3m2!1sen!2sgh!4v1674033679073!5m2!1sen!2sgh\",\"location\":\"asdsdadsa\",\"area\":\"saddsadsa\",\"bed\":\"3\",\"bath\":\"2\",\"kitchen\":\"2\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Air condition\",\"Kitchen\",\"Tv\",\"Internet\",\"Security service\",null],\"_token\":\"NfLmuYpGwna8hxZrSqSpH4rXbtU4Xo96eSFyGPrC\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-18 17:30:16', '2023-01-18 17:30:16'),
(524, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-18 17:30:17', '2023-01-18 17:30:17'),
(525, 1, 'admin', 'GET', '127.0.0.1', '[]', '2023-01-18 17:31:59', '2023-01-18 17:31:59'),
(526, 1, 'admin', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 17:32:03', '2023-01-18 17:32:03'),
(527, 1, 'admin/properties', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 17:32:04', '2023-01-18 17:32:04');
INSERT INTO `admin_operation_log` (`id`, `user_id`, `path`, `method`, `ip`, `input`, `created_at`, `updated_at`) VALUES
(528, 1, 'admin/properties/1/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 17:32:07', '2023-01-18 17:32:07'),
(529, 1, 'admin/properties/1', 'PUT', '127.0.0.1', '{\"title\":\"xzccxzcxzcxzcx\",\"description\":\"Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellat hic sunt pariatur omnis eum vero, incidunt facilis sapiente. Doloribus, accusamus. Rerum maxime consequuntur qui exercitationem quae corporis provident pariatur! Eveniet?\\r\\nConsectetur molestias reiciendis itaque cum magnam qui rerum facilis eos debitis nihil iste enim error quis nisi, aliquid natus non similique? Sequi quia cum ipsa voluptatibus, explicabo incidunt assumenda eaque!\\r\\nAtque repudiandae harum enim recusandae. Vel cum non doloribus odio labore facilis vero nobis saepe eius. Culpa voluptatum itaque porro maxime ex eos in, quod laudantium eveniet ducimus? Eos, possimus.\\r\\nDoloribus incidunt expedita corporis minima possimus. Ex atque error consequuntur architecto! Sint quidem aut voluptatum modi impedit laborum natus ea maiores ex tempore error laudantium explicabo est debitis, repellat velit.\\r\\nNam ex et aut hic magni nihil nobis minus architecto, id cumque harum facere voluptatibus molestias dolor porro facilis quaerat fugiat! Iusto ipsum veritatis adipisci est! Optio dignissimos quam corrupti?\",\"price\":\"3\",\"url\":\"https:\\/\\/www.google.com\\/maps\\/embed?pb=!1m18!1m12!1m3!1d15884.066269034032!2d-0.2983689!3d5.5645614!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf981a8975e7bb%3A0xc4d4487298accf44!2sMcCarthy%20Hill%2C%20Mallam!5e0!3m2!1sen!2sgh!4v1674033679073!5m2!1sen!2sgh\",\"location\":\"asdsdadsa\",\"area\":\"saddsadsa\",\"bed\":\"3\",\"bath\":\"2\",\"kitchen\":\"2\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Security_service\",\"Water_reservoir\",\"Concrete_Flooring\",null],\"_token\":\"NfLmuYpGwna8hxZrSqSpH4rXbtU4Xo96eSFyGPrC\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-18 17:32:21', '2023-01-18 17:32:21'),
(530, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-18 17:32:22', '2023-01-18 17:32:22'),
(531, 1, 'admin/properties/2/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 17:32:28', '2023-01-18 17:32:28'),
(532, 1, 'admin/properties/2', 'PUT', '127.0.0.1', '{\"title\":\"asddsadsa\",\"description\":\"Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellat hic sunt pariatur omnis eum vero, incidunt facilis sapiente. Doloribus, accusamus. Rerum maxime consequuntur qui exercitationem quae corporis provident pariatur! Eveniet?\\r\\nConsectetur molestias reiciendis itaque cum magnam qui rerum facilis eos debitis nihil iste enim error quis nisi, aliquid natus non similique? Sequi quia cum ipsa voluptatibus, explicabo incidunt assumenda eaque!\\r\\nAtque repudiandae harum enim recusandae. Vel cum non doloribus odio labore facilis vero nobis saepe eius. Culpa voluptatum itaque porro maxime ex eos in, quod laudantium eveniet ducimus? Eos, possimus.\\r\\nDoloribus incidunt expedita corporis minima possimus. Ex atque error consequuntur architecto! Sint quidem aut voluptatum modi impedit laborum natus ea maiores ex tempore error laudantium explicabo est debitis, repellat velit.\\r\\nNam ex et aut hic magni nihil nobis minus architecto, id cumque harum facere voluptatibus molestias dolor porro facilis quaerat fugiat! Iusto ipsum veritatis adipisci est! Optio dignissimos quam corrupti?\",\"price\":\"4\",\"url\":\"https:\\/\\/www.google.com\\/maps\\/embed?pb=!1m18!1m12!1m3!1d15884.066269034032!2d-0.2983689!3d5.5645614!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf981a8975e7bb%3A0xc4d4487298accf44!2sMcCarthy%20Hill%2C%20Mallam!5e0!3m2!1sen!2sgh!4v1674033679073!5m2!1sen!2sgh\",\"location\":\"asx\",\"area\":\"dsffd\",\"bed\":\"2\",\"bath\":\"2\",\"kitchen\":\"2\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Tiled\",\"Internet\",\"Security_service\",\"fenced\",null],\"_token\":\"NfLmuYpGwna8hxZrSqSpH4rXbtU4Xo96eSFyGPrC\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-18 17:32:42', '2023-01-18 17:32:42'),
(533, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-18 17:32:43', '2023-01-18 17:32:43'),
(534, 1, 'admin/properties/3/edit', 'GET', '127.0.0.1', '{\"_pjax\":\"#pjax-container\"}', '2023-01-18 17:32:46', '2023-01-18 17:32:46'),
(535, 1, 'admin/properties/3', 'PUT', '127.0.0.1', '{\"title\":\"asddsa\",\"description\":\"Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellat hic sunt pariatur omnis eum vero, incidunt facilis sapiente. Doloribus, accusamus. Rerum maxime consequuntur qui exercitationem quae corporis provident pariatur! Eveniet?\\r\\nConsectetur molestias reiciendis itaque cum magnam qui rerum facilis eos debitis nihil iste enim error quis nisi, aliquid natus non similique? Sequi quia cum ipsa voluptatibus, explicabo incidunt assumenda eaque!\\r\\nAtque repudiandae harum enim recusandae. Vel cum non doloribus odio labore facilis vero nobis saepe eius. Culpa voluptatum itaque porro maxime ex eos in, quod laudantium eveniet ducimus? Eos, possimus.\\r\\nDoloribus incidunt expedita corporis minima possimus. Ex atque error consequuntur architecto! Sint quidem aut voluptatum modi impedit laborum natus ea maiores ex tempore error laudantium explicabo est debitis, repellat velit.\\r\\nNam ex et aut hic magni nihil nobis minus architecto, id cumque harum facere voluptatibus molestias dolor porro facilis quaerat fugiat! Iusto ipsum veritatis adipisci est! Optio dignissimos quam corrupti?\",\"price\":\"5\",\"url\":\"https:\\/\\/www.google.com\\/maps\\/embed?pb=!1m18!1m12!1m3!1d15884.066269034032!2d-0.2983689!3d5.5645614!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf981a8975e7bb%3A0xc4d4487298accf44!2sMcCarthy%20Hill%2C%20Mallam!5e0!3m2!1sen!2sgh!4v1674033679073!5m2!1sen!2sgh\",\"location\":\"asdsdadsa\",\"area\":\"asddsa\",\"bed\":\"5\",\"bath\":\"3\",\"kitchen\":\"4\",\"_file_sort_\":{\"pictures\":null},\"amenities\":[\"Tiled\",\"Security_service\",\"fenced\",\"Concrete_Flooring\",null],\"_token\":\"NfLmuYpGwna8hxZrSqSpH4rXbtU4Xo96eSFyGPrC\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/127.0.0.1:8000\\/admin\\/properties\"}', '2023-01-18 17:33:04', '2023-01-18 17:33:04'),
(536, 1, 'admin/properties', 'GET', '127.0.0.1', '[]', '2023-01-18 17:33:05', '2023-01-18 17:33:05');

-- --------------------------------------------------------

--
-- Table structure for table `admin_permissions`
--

DROP TABLE IF EXISTS `admin_permissions`;
CREATE TABLE IF NOT EXISTS `admin_permissions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `http_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `http_path` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_permissions_name_unique` (`name`),
  UNIQUE KEY `admin_permissions_slug_unique` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_permissions`
--

INSERT INTO `admin_permissions` (`id`, `name`, `slug`, `http_method`, `http_path`, `created_at`, `updated_at`) VALUES
(1, 'All permission', '*', '', '*', NULL, NULL),
(2, 'Dashboard', 'dashboard', 'GET', '/', NULL, NULL),
(3, 'Login', 'auth.login', '', '/auth/login\r\n/auth/logout', NULL, NULL),
(4, 'User setting', 'auth.setting', 'GET,PUT', '/auth/setting', NULL, NULL),
(5, 'Auth management', 'auth.management', '', '/auth/roles\r\n/auth/permissions\r\n/auth/menu\r\n/auth/logs', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_roles`
--

DROP TABLE IF EXISTS `admin_roles`;
CREATE TABLE IF NOT EXISTS `admin_roles` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_roles_name_unique` (`name`),
  UNIQUE KEY `admin_roles_slug_unique` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_roles`
--

INSERT INTO `admin_roles` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 'administrator', '2022-12-17 23:13:29', '2022-12-17 23:13:29');

-- --------------------------------------------------------

--
-- Table structure for table `admin_role_menu`
--

DROP TABLE IF EXISTS `admin_role_menu`;
CREATE TABLE IF NOT EXISTS `admin_role_menu` (
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_menu_role_id_menu_id_index` (`role_id`,`menu_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_role_menu`
--

INSERT INTO `admin_role_menu` (`role_id`, `menu_id`, `created_at`, `updated_at`) VALUES
(1, 2, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_role_permissions`
--

DROP TABLE IF EXISTS `admin_role_permissions`;
CREATE TABLE IF NOT EXISTS `admin_role_permissions` (
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_permissions_role_id_permission_id_index` (`role_id`,`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_role_permissions`
--

INSERT INTO `admin_role_permissions` (`role_id`, `permission_id`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_role_users`
--

DROP TABLE IF EXISTS `admin_role_users`;
CREATE TABLE IF NOT EXISTS `admin_role_users` (
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_users_role_id_user_id_index` (`role_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_role_users`
--

INSERT INTO `admin_role_users` (`role_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_users_username_unique` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`, `name`, `avatar`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$10$FPPW4yDXBBMP8s3ybydB0.4X5EfK94Q1accNNkchUkQI.3ch4d.86', 'Administrator', NULL, 'VbsqjUCKbouisoWVIPP24onHmBfYPTaskmCm2p2lR33LUBIBlRY4JLEDwOGr', '2022-12-17 23:13:29', '2022-12-17 23:13:29');

-- --------------------------------------------------------

--
-- Table structure for table `admin_user_permissions`
--

DROP TABLE IF EXISTS `admin_user_permissions`;
CREATE TABLE IF NOT EXISTS `admin_user_permissions` (
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_user_permissions_user_id_permission_id_index` (`user_id`,`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
CREATE TABLE IF NOT EXISTS `appointments` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `propertyname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `name`, `email`, `phone`, `date`, `time`, `created_at`, `updated_at`, `propertyname`) VALUES
(1, 'ebenezer', 'tijani.mohammed@regent.edu.gh', '0240994061', '2023-01-17', '23:10:00', '2023-01-18 15:10:49', '2023-01-18 15:10:49', ''),
(2, 'ebenezer', 'tijani.mohammed@regent.edu.gh', '0240994061', '2023-01-17', '23:16:00', '2023-01-18 15:16:27', '2023-01-18 15:16:27', ''),
(3, 'ebenezer', 'tijani.mohammed@regent.edu.gh', '0240994061', '2023-01-17', '23:17:00', '2023-01-18 15:17:52', '2023-01-18 15:17:52', ''),
(4, 'eben@example.com', 'edsddsben@example.cg', 'hkkkjuioou', '2023-01-19', '04:05:00', '2023-01-19 19:05:46', '2023-01-19 19:05:46', 'asddsadsa');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
CREATE TABLE IF NOT EXISTS `contacts` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `email`, `content`, `created_at`, `updated_at`) VALUES
(1, 'tijani.mohammed@regent.edu.gh', 'dafdsfdasffds', '2023-01-18 14:39:53', '2023-01-18 14:39:53'),
(2, 'tijani.mohammed@regent.edu.gh', '\\zxc\\zcx\\zx', '2023-01-18 17:36:44', '2023-01-18 17:36:44'),
(3, 'edsddsben@example.cg', 'asdasdsadad', '2023-01-19 19:06:54', '2023-01-19 19:06:54');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `histories`
--

DROP TABLE IF EXISTS `histories`;
CREATE TABLE IF NOT EXISTS `histories` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_channel` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `paid_amount` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `histories`
--

INSERT INTO `histories` (`id`, `username`, `customer_id`, `email`, `payment_channel`, `paid_amount`, `created_at`, `updated_at`) VALUES
(1, 'eben@example.com', 'qkse6uwn45', 'edsddsben@example.cg', 'mobile_money', '5.00', '2023-01-19 09:04:02', '2023-01-19 09:04:02');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_01_04_173148_create_admin_tables', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2022_12_17_071549_create_properties_table', 2),
(7, '2022_12_17_071602_create_property_types_table', 2),
(8, '2023_01_01_233350_create_properties_table', 3),
(9, '2023_01_01_234151_create_properties_table', 4),
(10, '2023_01_03_140555_create_appointments_table', 5),
(11, '2023_01_15_010939_create_contacts_table', 6),
(12, '2023_01_17_210926_create_properties_table', 7),
(13, '2023_01_18_015536_create_users_table', 8),
(14, '2023_01_18_064956_create_appointments_table', 9),
(15, '2023_01_18_100530_create_histories_table', 10);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

DROP TABLE IF EXISTS `properties`;
CREATE TABLE IF NOT EXISTS `properties` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bed` int(11) NOT NULL,
  `bath` int(11) NOT NULL,
  `kitchen` int(11) NOT NULL,
  `pictures` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `amenities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`id`, `title`, `description`, `price`, `url`, `location`, `area`, `bed`, `bath`, `kitchen`, `pictures`, `amenities`, `created_at`, `updated_at`) VALUES
(1, 'xzccxzcxzcxzcx', 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellat hic sunt pariatur omnis eum vero, incidunt facilis sapiente. Doloribus, accusamus. Rerum maxime consequuntur qui exercitationem quae corporis provident pariatur! Eveniet?\r\nConsectetur molestias reiciendis itaque cum magnam qui rerum facilis eos debitis nihil iste enim error quis nisi, aliquid natus non similique? Sequi quia cum ipsa voluptatibus, explicabo incidunt assumenda eaque!\r\nAtque repudiandae harum enim recusandae. Vel cum non doloribus odio labore facilis vero nobis saepe eius. Culpa voluptatum itaque porro maxime ex eos in, quod laudantium eveniet ducimus? Eos, possimus.\r\nDoloribus incidunt expedita corporis minima possimus. Ex atque error consequuntur architecto! Sint quidem aut voluptatum modi impedit laborum natus ea maiores ex tempore error laudantium explicabo est debitis, repellat velit.\r\nNam ex et aut hic magni nihil nobis minus architecto, id cumque harum facere voluptatibus molestias dolor porro facilis quaerat fugiat! Iusto ipsum veritatis adipisci est! Optio dignissimos quam corrupti?', 3, 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15884.066269034032!2d-0.2983689!3d5.5645614!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf981a8975e7bb%3A0xc4d4487298accf44!2sMcCarthy%20Hill%2C%20Mallam!5e0!3m2!1sen!2sgh!4v1674033679073!5m2!1sen!2sgh', 'asdsdadsa', 'saddsadsa', 3, 2, 2, '[\"images\\/4ec24228635e9d9ad901055b0e5a5e50.jpg\",\"images\\/d6bfaf6bc0139a027bf140fcf41977dc.webp\",\"images\\/9c1e7df60f8b5e5eb53d6e3684569961.jpg\"]', 'Security_service,Water_reservoir,Concrete_Flooring', '2023-01-18 05:20:24', '2023-01-18 17:32:21'),
(2, 'asddsadsa', 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellat hic sunt pariatur omnis eum vero, incidunt facilis sapiente. Doloribus, accusamus. Rerum maxime consequuntur qui exercitationem quae corporis provident pariatur! Eveniet?\r\nConsectetur molestias reiciendis itaque cum magnam qui rerum facilis eos debitis nihil iste enim error quis nisi, aliquid natus non similique? Sequi quia cum ipsa voluptatibus, explicabo incidunt assumenda eaque!\r\nAtque repudiandae harum enim recusandae. Vel cum non doloribus odio labore facilis vero nobis saepe eius. Culpa voluptatum itaque porro maxime ex eos in, quod laudantium eveniet ducimus? Eos, possimus.\r\nDoloribus incidunt expedita corporis minima possimus. Ex atque error consequuntur architecto! Sint quidem aut voluptatum modi impedit laborum natus ea maiores ex tempore error laudantium explicabo est debitis, repellat velit.\r\nNam ex et aut hic magni nihil nobis minus architecto, id cumque harum facere voluptatibus molestias dolor porro facilis quaerat fugiat! Iusto ipsum veritatis adipisci est! Optio dignissimos quam corrupti?', 4, 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15884.066269034032!2d-0.2983689!3d5.5645614!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf981a8975e7bb%3A0xc4d4487298accf44!2sMcCarthy%20Hill%2C%20Mallam!5e0!3m2!1sen!2sgh!4v1674033679073!5m2!1sen!2sgh', 'asx', 'dsffd', 2, 2, 2, '[\"images\\/33b8c5df4ce6adec6635c96c4885bf19.jpg\",\"images\\/7e95b0c65673f62737b5d4fbf32f1cb0.jpeg\",\"images\\/9d6509f675bb8f6b90cd528aebe407f8.jpeg\"]', 'Tiled,Internet,Security_service,fenced', '2023-01-18 05:20:54', '2023-01-18 17:32:43'),
(3, 'asddsa', 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repellat hic sunt pariatur omnis eum vero, incidunt facilis sapiente. Doloribus, accusamus. Rerum maxime consequuntur qui exercitationem quae corporis provident pariatur! Eveniet?\r\nConsectetur molestias reiciendis itaque cum magnam qui rerum facilis eos debitis nihil iste enim error quis nisi, aliquid natus non similique? Sequi quia cum ipsa voluptatibus, explicabo incidunt assumenda eaque!\r\nAtque repudiandae harum enim recusandae. Vel cum non doloribus odio labore facilis vero nobis saepe eius. Culpa voluptatum itaque porro maxime ex eos in, quod laudantium eveniet ducimus? Eos, possimus.\r\nDoloribus incidunt expedita corporis minima possimus. Ex atque error consequuntur architecto! Sint quidem aut voluptatum modi impedit laborum natus ea maiores ex tempore error laudantium explicabo est debitis, repellat velit.\r\nNam ex et aut hic magni nihil nobis minus architecto, id cumque harum facere voluptatibus molestias dolor porro facilis quaerat fugiat! Iusto ipsum veritatis adipisci est! Optio dignissimos quam corrupti?', 5, 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15884.066269034032!2d-0.2983689!3d5.5645614!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdf981a8975e7bb%3A0xc4d4487298accf44!2sMcCarthy%20Hill%2C%20Mallam!5e0!3m2!1sen!2sgh!4v1674033679073!5m2!1sen!2sgh', 'asdsdadsa', 'asddsa', 5, 3, 4, '[\"images\\/f7541630db3d5ba8b78e23ad9482e631.webp\",\"images\\/b38ab00fcbdc3a0201008ceff8cc68b8.jpeg\",\"images\\/261a567d8cbfd775a3e5c6f2bfc9b354.jpeg\"]', 'Tiled,Security_service,fenced,Concrete_Flooring', '2023-01-18 05:21:53', '2023-01-18 17:33:04');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'ebenezer', 'ebenezer.gyamfi@regent.edu.gh', NULL, '$2y$10$S4.fp6od1pCcFcz4GgawM.VHygcwFz75CyhDOuvtYHOUVRuT.QL..', NULL, '2023-01-18 09:56:13', '2023-01-18 09:56:13'),
(2, 'ebenezer', 'example@gmail.com', NULL, '$2y$10$y45zk8L1DRq3xVDCP4n2fO/lc/VXLS1ojyzccckx6C.jDGKZ8Ywim', NULL, '2023-01-18 10:55:01', '2023-01-18 10:55:01'),
(3, 'eben', 'eben@example.com', NULL, '$2y$10$kUWPiGbIIIWHMqye9tztweNE7Ipy63hNmZyygWRb6JtDLVcbG5PXu', NULL, '2023-01-19 08:44:20', '2023-01-19 08:44:20'),
(4, 'eben@example.com', 'some@exaple.com', NULL, '$2y$10$wbdRSgxApUIWloF2p.nzEOtjG4Tepv/6RFNF8xx.QqUfa58YVAsRq', NULL, '2023-01-19 08:47:02', '2023-01-19 08:47:02'),
(5, 'eben@example.com', 'edsddsben@example.cg', NULL, '$2y$10$7NypEs0K5ek3/plONKLo6eiNt4Fzvw00MkXwMTqDmqG9R3j6QqyQO', NULL, '2023-01-19 08:51:03', '2023-01-19 08:51:03');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
